
Curso de Python Avanzado
========================

Temario
-------

1. **Bloque 0:** El lenguaje en profundidad

  - Tema 0: Introducción y repaso.
  - Tema 1: Programación Funcional
  - Tema 2: Orientación a Objetos
  - Tema 3: Cuestiones avanzadas 
