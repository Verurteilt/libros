"""
Documentacion.
"""

def good_func ():
    """
    Documentacion.
    """
    print "Funcion de " + __name__
