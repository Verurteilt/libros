# -*- coding: utf-8 -*-
"""
Este es un modulo muy bueno!
"""

def fun ():
    """
    Esta es una funcion muy util!
    """ 
    print "Hola mundo!"


class MyClass (object):
    """
    Una clase chula.
    """

    def method (self, param):
        """
        Un metodo fascinante.
        :param param: Esto mola
        """

if __name__ == '__main__':
    print "** Probando fun ()"
    fun ()
