

def bad_func ():
    print "Hola mundo"
