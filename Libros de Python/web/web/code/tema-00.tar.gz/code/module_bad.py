
def fun ():
    print "¡Hola Mundo!"

print "** Probando fun:"
fun()
