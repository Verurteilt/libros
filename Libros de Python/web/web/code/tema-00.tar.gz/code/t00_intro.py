"""

INTRODUCCION
============

1. Objetivos del curso
----------------------

- Aprender el lenguaje en profundidad.
- Aprender a hacer aplicaciones medianas-grandes:
  * Trucos 'idiomaticos', modularidad, organización.
- Aprender a hacer aplicaciones en los campos en los que Python es
  mejor:
  * Interfaces gráficas, sistemas web, prototipados

"""

"""

2. Algunas herramientas
-----------------------

- Yo voy a usar Emacs.
  * Puedo ejecutar trozos de código.
  * Me muestra los errores en rojo (esto no va por defecto.)

"""

print "Hola Emacs!"

"""

- Cuantos colorines!
- Eso se llama ipython -- Interactive Python
  * Shell orientada a ser usada en directo
  * ¿Por qué?:
    > Es mejor editando.
    > Permite ejecutar comandos de la shell. %alias.
    > Ayuda accesible ? ó ??.
    > Comandos especiales. %magic, %quickref
      %run
      %reset
      %edit
    > Auto-parentesis
    > Auto-historia _i _ii _iii _ih[n]
    > %quickref

"""

"""

Repaso
------

"""

"""

Valores, operadores ...

"""
1 == 1
1 is 1
[1] == [1]
[1] is [1]
type (1.2)
a = 2
a += 1
print a

"""

Listas, cadenas ...

"""

s = 'abc'
s.replace ('b', 'B')
print s
'hola' is 'hola'
s2 = list (s)
s2[1] = 'B'
print s2
print ''.join (s2)
range (2, 22, 2)
[3, 'hola', 5.2]
[ x**2 for x in range(10) if x%2==0]
if []: 
    print "No me ejecuto"

"""

Diccionarios ...

"""

a = { 'java' : 'inquisicion',
      'python' : 'renacimiento',
      'lisp' : 1958,
      'cobol' : None }
a['python'] == 'renacimiento'
a['lisp'] += 1
del a['java']
b = dict ([(1, 9), (1, 10), (2, 20)])
n = 'Juan Pedro Bolivar Puente'
dict (zip (range (len (n)), n))

"""

Bucles ...

"""

for idx in range (5):
    print idx

for key, val in b.iteritems ():
    print key, '->', val

while True:
    s = raw_input ('Dime guapo: ')
    if s.lower () == 'guapo':
        break

"""

Funciones, entrada y salida ...

"""

import sys
def acrostico (fname):
    f = open (fname)
    for x in f.readlines ():
        sys.stdout.write (
            x[0].replace ('\n', ' '))

def saludar (despedida = False):
    if despedida:
       print "Adios mundo!"
    else:
       print "hola mundo!"

saludar ()
saludar (True)
saludar (despedida = True)

"""

3. Modularidad
--------------

  - Hemos visto que Python tiene módulos.
  - Se pueden importar de diversas formas.

"""

import os
print os.name

from os import name
print name

from os import path
print path.join ('una', 'ruta')

import os.path as p
print p.exists ('/')

"""

  Internamente la sentencia import llama a la
  función __import__. Esta función podemos incluso
  reescribirla para que haga lo que queramos.

"""

os = __import__ ('os')
print os.name

"""

Búsqueda de Módulo:

  - Busca un fichero con ese nombre en el directorio actual.
  - Sub módulos en directorios anidados con un __init__.py
  - Repite el proceso.
  - Si no encuentra tira ImportError
    => ¡Funcionalidad opcional!

Carga de módulo:

  - Al cargar un módulo *se ejecuta*.
  - Nombre del modulo en __name__
  - Modulo 'raiz' => '__main__'

NOTA TERMINOLOGICA:

  - En Python normalmente se llama 'paquete' y no
    modulo a un directorio que contiene otros
    modulos.

  - Se llama 'modulo' solo ha un modulo hoja.

"""

import module_bad
import module_good

try:
    import module_bad.submodule
except ImportError:
    print "No encuentra el modulo"

import module_good.submodule
module_good.submodule.good_func ()

"""

Documentando
------------

  - Vimos en el curso anterior que una funcion
    puede documentarse en Python y esa información
    accederse con help ()

  - Los modulos también pueden documentarse con
    una docstring que aparezca antes que la
    primera sentencia.

  - Las clases (las repasaremos luego) tambien.

  - Ipython ayuda a ver la documentación.

"""

help (module_good)
help (module_good.fun)
help (module_good.MyClass)

print module_good.__doc__
print module_good.fun.__doc__
print module_good.MyClass.__doc__

print module_good.__name__
print module_good.fun.__name__
print module_good.MyClass.__name__
