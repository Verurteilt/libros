#
#  File:       models.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Thu Jun 24 11:28:15 2010
#  Time-stamp: <2010-08-22 22:58:09 raskolnikov>
#

"""
  Model for the auctions application.
"""

from core import locking
from django.db.models import signals
from django.db import models
from django.contrib.auth.models import User
import settings
from decimal import Decimal
from django.shortcuts import get_object_or_404
from os import path
from datetime import timedelta, datetime
from functools import partial
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ugettext

def auction_picture_file (instance, filename):
    return path.join ('pics', str (instance.pk or 'new'))

default_picture = 'no-picture.png'

MoneyField = partial (models.DecimalField,
                      decimal_places = 2,
                      max_digits     = 20)

soft_deadline_delta = timedelta (minutes = 5)


class BidError (Exception):
    pass


class Auction (models.Model):

    class Meta:
         permissions = (('can_ban_auction', 'Can ban an auction'),)

    owner         = models.ForeignKey (User, editable = False)
    
    name          = models.CharField (max_length = 256)
    description   = models.TextField (max_length = 4096)
    minimum_bid   = MoneyField (verbose_name = _("Minimum bid (%s)") %
                                settings.CURRENCY_SYMBOL)

    finishes_on   = models.DateTimeField (
        default = lambda: datetime.now () + timedelta (days = 7))
    
    created_on    = models.DateTimeField (default  = datetime.now,
                                          editable = False)

    finishes_on_ex = models.DateTimeField (blank = True, null = True,
                                           editable = False)
    
    soft_deadline = models.BooleanField ()
    picture       = models.ImageField (upload_to = auction_picture_file,
                                       default   = default_picture,
                                       blank     = True)
    
    banned        = models.BooleanField (default = False, editable = False)
    resolved      = models.BooleanField (default = False, editable = False)

    time_stamp    = models.DateTimeField (auto_now = True)
   
    @property
    def bids (self):
        return Bid.filter (auction = self)

    @property
    def has_expired (self):
        if self.finishes_on_ex:
            return self.finishes_on_ex < datetime.now ()
        return self.finishes_on < datetime.now ()

    @property
    def is_within_soft_deadline (self):
        return soft_deadline_delta + datetime.now () > self.finishes_on

    def extend_soft_deadline (self):
        if self.finishes_on_ex:
            self.finishes_on_ex = self.finishes_on_ex + soft_deadline_delta
        else:
            self.finishes_on_ex = self.finishes_on + soft_deadline_delta
    
    @property
    def highest_bid (self):
        try:
            return Bid.objects.filter (auction = self).order_by ('-ammount') [0]
        except IndexError:
            return None

    @property
    def next_bid (self):
        bid = self.highest_bid
        if bid:
            return bid.ammount + Decimal ('0.01')
        return self.minimum_bid
        
    @models.permalink
    def get_absolute_url(self):
        return ('auction.views.detail', [ str (self.id) ])

    
class Bid (models.Model):
    """
    A bid without user is the minimum bid, useful for ordering by
    price when searching.

    TODO: Update fixtures and enforce this requirement in different
    parts of the program.

    TODO: I just realized that also the minimum bid is not enforced
    when editing an auction.
    """
    
    class Meta:
        order_with_respect_to = 'auction'
        ordering = [ 'ammount' ]

    auction       = models.ForeignKey (Auction,
                                       editable = False)
    ammount       = MoneyField (default = '0.00')
    who           = models.ForeignKey (User,
                                       null     = True,
                                       blank    = True,
                                       editable = False)
    time_stamp    = models.DateTimeField (default = datetime.now,
                                          editable = False)


@locking.require_lock_model (Bid)
def handle_minimum_bid_enforcement (sender, instance = None, created = False, **k):
    """
    Enforces the condition that there exists a bid win no user with
    the minimum bid for all auctions. This allows easier ordering by
    price using bid__ammount.
    """
    bid, bid_created = Bid.objects.get_or_create (auction = instance, who = None)
    bid.ammount      = instance.minimum_bid
    bid.time_stamp   = instance.created_on
    bid.save ()

signals.post_save.connect (handle_minimum_bid_enforcement, sender = Auction)


@locking.require_lock_model (Auction)
def do_check_soft_deadline (auction_id):
    """ We get the object again so the lock applies """
    auction = Auction.objects.get (pk = auction_id)
    if auction.is_within_soft_deadline:
        auction.extend_soft_deadline ()


def can_bid (user, auction):
    return user and not user.is_anonymous () and \
           auction.owner != user and \
           (not auction.highest_bid or auction.highest_bid.who != user)


@locking.require_lock_model (Bid)
def do_bid (auction_or_id, bid_ammount, user):
    if not isinstance (auction_or_id, Auction):
        auction_or_id = get_object_or_404 (Auction, pk = auction_or_id)

    if auction_or_id.has_expired:
        raise BidError (ugettext ("Can not bid when the deadline is over."))

    if auction_or_id.owner == user:
        raise BidError (ugettext ("You can not bid in your own auctions."))
    
    if not auction_or_id.highest_bid or auction_or_id.highest_bid.who == user:
        raise BidError (ugettext ("You are already made the highest bid."))

    if bid_ammount < auction_or_id.next_bid:
        raise BidError (
            ugettext (
                "Your bid must be at least %(min_bid)s but yours is %(ammount)s") %
            { 'ammount' : str (bid_ammount),
              'min_bid' : str (auction_or_id.next_bid) })

    Bid (auction = auction_or_id, who = user, ammount = bid_ammount).save ()

    if auction_or_id.soft_deadline:
        do_check_soft_deadline (auction_or_id.pk)


def minimum_bid (auction, time = None):
    if time is None:
        time = datetime.now ()
    try:
        bid = Bid.objects.filter (
            auction = auction,
            time_stamp__lt = time).order_by ('-time_stamp') [0]
    except IndexError:
        bid = None
    return bid


def maximum_bid (auction, time = None, max_bid = '1000000.0'):
    if time is None:
        time = auction.created_on
    try:
        bid = Bid.objects.filter (
            auction = auction,
            time_stamp__gt = time).order_by ('time_stamp') [0]
    except IndexError:
        bid = None
    return bid


