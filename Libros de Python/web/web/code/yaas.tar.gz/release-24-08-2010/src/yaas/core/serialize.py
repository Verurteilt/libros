#
#  File:       serialize.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Tue Aug 17 20:15:59 2010
#  Time-stamp: <2010-08-23 12:13:23 raskolnikov>
#

"""
  Simple data serialization interface.
"""

try:
    from lxml import etree
    has_xml_pretty_print = True
except ImportError:
    import xml.etree.ElementTree as etree
    has_xml_pretty_print = False
    
from functools import partial
from core import util
import json
try:
    import yaml
except ImportError:
    pass


def to_data_object (tag, content):
    return { tag : content, '__collapsable__' : tag }


def namer_try_singular (n, default = 'item'):
    if len (n) > 2 and n[-2:-1] == 'es':
        return n[:-2]
    if len (n) > 1 and n[-1] == 's':
        return n[:-1]
    return default


def is_object_heuristic (data):
    return isinstance (data, dict) and \
            ('__collapsable__' in data or len (data) == 1)


def expand_data (data, parent = 'objects', item_namer = namer_try_singular):
    if isinstance (data, list) and \
        not (util.count_if (data, is_object_heuristic)) == len (data):
        return map (partial (to_data_object, item_namer (parent)),
                    map (partial (expand_data, parent = parent,
                                  item_namer = item_namer), data))
    elif isinstance (data, dict):
        return dict ([ (k, expand_data (v, k, item_namer))
                       for k, v in data.iteritems () ])
    else:
        return data

    
def collapse_data (data, greedy = False):
    if isinstance (data, dict):
        if '__collapsable__' in data:
            return collapse_data (data [data ['__collapsable__']], greedy)
        elif greedy and len (data) == 1:
            return collapse_data (data.itervalues ().next (), greedy)
        else:
            return dict ([(k, collapse_data (v, greedy))
                          for k, v in data.iteritems ()])
    elif isinstance (data, list):
        return map (partial (collapse_data, greedy = greedy), data)
    else:
        return data


def do_data_to_etree (data, parent):
    if isinstance (data, dict):
        for k, v in data.iteritems ():
            if k [:2] != '__':
                do_data_to_etree (v, etree.SubElement (parent, k))
    elif isinstance (data, list):
        for x in data:
            do_data_to_etree (x, parent)
    else:
        parent.text = unicode (data)

def data_to_etree (data, root_tag = 'root'):
    root = etree.Element (root_tag)
    do_data_to_etree (data, root)
    return root

def etree_to_data (et):
    if len (et) == 0:
        # We generate redundant objects that will be collapsed later
        # for the leaves.
        return to_data_object (et.text)
    elif util.is_set ([x.tag for x in et]):
        # We heuristically assume that if all the childs are distinct
        # they are the attributes of an object.
        return to_data_object (
            et.tag, dict ([(x.tag, etree_to_data (x)) for x in et]))
    else:
        # We heuristically assume that we are otherwise in front of a
        # list. We can easily fall into list of lists when parsing
        # arbitrary XML but it should be fine for XML designed to work
        # from 'data_to_etree'.
        return [ etree_to_data (x) for x in et ]


def serialize_data_xml (data, root_tag = 'root', indent = 0, *a, **k):
    kk = { 'pretty_print' : indent > 0 } if has_xml_pretty_print else {}
    return etree.tostring (data_to_etree (expand_data (data),
                                          root_tag = root_tag), ** kk)

def deserialize_data_xml (string):
    return collapse_data (etree_to_data (etree.XML (string)))

def serialize_data_json (data, indent = None, *a, **k):
    return json.dumps (collapse_data (data), indent = indent)

def deserialize_data_json (string, *a, **k):
    return json.loads (string)

def serialize_data_yaml (data, indent = None, *a, **k):
    return yaml.safe_dump (collapse_data (data), indent = indent)

def deserialize_data_yaml (string, *a, **k):
    return yaml.load (string)
    
def serialize_data (format, data, *a, **k):
    return DATA_SERIALIZERS [format] (data, *a, **k)

def deserialize_data (format, string):
    return DATA_DESERIALIZERS [format] (string)

DATA_SERIALIZERS = {
    'xml'  : serialize_data_xml,
    'json' : serialize_data_json,
    'yaml' : serialize_data_yaml,
    }

DATA_DESERIALIZERS = {
    'xml'  : deserialize_data_xml,
    'json' : deserialize_data_json,
    'yaml' : deserialize_data_yaml,
    }
