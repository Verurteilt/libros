#
#  File:       forms.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sat Aug 14 20:20:10 2010
#  Time-stamp: <2010-08-22 18:17:55 raskolnikov>
#

"""
  Forms for the user manager.
"""

from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _
from django.core import validators
import core.forms
from django import forms
from core.forms import ExtendForm
import django.contrib.auth.forms as authforms
from models import UserProfile


class UserProfileForm (forms.ModelForm, ExtendForm):

    class Meta:
        model = UserProfile


class UserForm (forms.ModelForm, ExtendForm):

    class Meta:
        model  = User
        fields =  ('username', 'email', 'first_name', 'last_name')

    email = forms.CharField (
        label       = _('Email address'),
        max_length  = 30,
        required    = True,
        validators  = [ validators.validate_email ])

    def clean_email (self):
        exclude_pk = self.instance and self.instance.pk
        return core.forms.validate_unique (User, 'email', exclude_pk) (
            self.cleaned_data.get ('email'))


class RegisterForm (forms.Form, ExtendForm):
    
    new_username = forms.CharField (
        label       = _('Username'),
        max_length  = 30,
        required    = True,
        validators  = [ core.forms.validate_unique (User, 'username') ])
            
    new_email = forms.CharField (
        label       = _('Email address'),
        max_length  = 30,
        required    = True,
        validators  = [
            validators.validate_email,
            core.forms.validate_unique (User, 'email') ])
            
    new_password1 = forms.CharField (
        label       = _('Password'),
        max_length  = 60,
        widget      = forms.PasswordInput (render_value = False),
        required    = True)
    
    new_password2 = forms.CharField (
        label       = _('Repeat password'),
        max_length  = 60,
        required    = True,
        widget      = forms.PasswordInput ())
    
    def save (self):
        u = User.objects.create_user (self.cleaned_data ['new_username'],
                                      self.cleaned_data ['new_email'],
                                      self.cleaned_data ['new_password1'])
        u.is_active = False
        u.save ()
        return u

    clean_new_password2 = core.forms.clean_repeat (
        'new_password2',
        'new_password1',
        _("The given passwords do not match."))

