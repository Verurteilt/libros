#
#  File:       paging.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sun Jun 27 04:25:30 2010
#  Time-stamp: <2010-08-16 19:53:08 raskolnikov>
#

"""
  Extra filter tags for pagination.
"""

from django import template
from core import util

register = template.Library ()

PAGE_SUBRANGE_SIZE = 15


@register.filter
def pages_before (page_range, center):
    return util.take_until (pages_around (page_range, center),
                            lambda x: x >= center)


@register.filter
def pages_after (page_range, center):
    return util.drop_until (pages_around (page_range, center),
                            lambda x: x > center)


@register.filter
def pages_around (page_range, center):
    half_pages = PAGE_SUBRANGE_SIZE / 2
    center -= 1
    length = len (page_range)
    first  = max (0, center - half_pages)
    last   = min (length, center + half_pages + 1)
    if last - first < PAGE_SUBRANGE_SIZE:
        if first is 0:
            last = min (length, half_pages * 2 + 1)
        if last is length:
            first = max (0, length - half_pages * 2)
    return page_range [first:last]

