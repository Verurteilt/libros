#
#  File:       urls.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 23 16:18:23 2010
#  Time-stamp: <2010-08-21 19:37:29 raskolnikov>
#

"""
  Urls for the user app.
"""

from django.conf.urls.defaults import *

urlpatterns = patterns (
    '',
    (r'^login$',                      'user.views.login'),
    (r'^logout$',                     'user.views.logout'),
    (r'^register$',                   'user.views.register'),
    (r'^edit$',                       'user.views.edit'),
    (r'^confirm/(\w{40})$',           'user.views.confirm'),
    (r'^detail/(?P<username>[\w\W]+)$',   'user.views.detail'),
    (r'^profile$',                    'user.views.detail'),
    (r'^change_password',             'user.views.change_password')
)
