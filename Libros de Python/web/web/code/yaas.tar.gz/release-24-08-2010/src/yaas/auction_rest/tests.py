#
#  File:       tests.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sun Aug 22 22:37:49 2010
#  Time-stamp: <2010-08-23 20:30:36 raskolnikov>
#

"""
  Functional tests for the auction rest api.

  TODO: Here we test things like autentication, formats, etc... that
  should be tested in the 'core' common application.
"""

from django.test import TestCase
from django.test.client import Client
from core.serialize import serialize_data
from core import rest
from views import data_from_auction_detailed
from auction import models
from decimal import Decimal
from datetime import datetime

class DetailFormatTest (TestCase):

    fixtures = [ 'auctions.json' ]

    def do_test_format (self, format, **k):
        c = Client ()
        r = c.get ('/api/v1/%s/auction/1' % format)
        self.assertEquals (r.mimetype, 'application/%s' % format)
        self.assertEquals (r.content, serialize_data (
            format, data_from_auction_detailed (
                models.Auction.objects.get (pk=1)), **k))
       
    def test_detail_format_xml (self):
        self.do_test_format ('xml', root_tag = 'auction-detail')

    def test_detail_format_json (self):
        self.do_test_format ('json')

    def test_detail_format_yaml (self):
        self.do_test_format ('json')


class BidTest (TestCase):

    fixtures = [ 'auctions.json' ]

    def test_auth_fail (self):
        c = Client ()
        response = c.post ('/api/v1/yaml/auction/1/bid',
                           'ammount: 40.0',
                           content_type='application/yaml')
        self.assertEquals (response.status_code, 401)
        self.assertEquals (models.Auction.objects.get (pk=1).highest_bid.who, None)


    def test_ok (self):
        c = Client ()
        response = c.post ('/api/v1/yaml/auction/1/bid',
                           'ammount: 40.0',
                           content_type='application/yaml',
                           HTTP_AUTHORIZATION=rest.to_authorization (
                               'aurora', 'aurora'))
        print response.content
        self.assertEquals (response.status_code, 200)
        self.assertEquals (
            models.Auction.objects.get (pk=1).highest_bid.who.username, 'aurora')
        self.assertEquals (
            models.Auction.objects.get (pk=1).highest_bid.ammount, Decimal ('40'))


    def test_bad (self):
        c = Client ()
        response = c.post (
            '/api/v1/yaml/auction/1/bid',
            'ammount: 10.0',
            content_type='application/yaml',
            HTTP_AUTHORIZATION = rest.to_authorization ('root', 'root'))
        self.assertEquals (response.status_code, 400)
        self.assertEquals (
            models.Auction.objects.get (pk=1).highest_bid.who, None)


class SearchTest (TestCase):

    def test_modified_since_positive (self):
        c = Client ()
        response = c.get ('/api/v1/yaml/auction',
                          HTTP_IF_MODIFIED_SINCE=rest.formatdate (
                              datetime (
                                  year = 2000, month = 1, day = 1).toordinal ()))
        self.assertTrue (response.status_code, 200)

    def test_modified_since_negative (self):
        c = Client ()
        response = c.get ('/api/v1/yaml/auction',
                          HTTP_IF_MODIFIED_SINCE=rest.formatdate (
                              datetime (
                                  year = 3000, month = 1, day = 1).toordinal ()))
        self.assertTrue (response.status_code, 304)



