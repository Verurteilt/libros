#
#  File:       views.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 16 15:03:30 2010
#  Time-stamp: <2010-08-21 17:53:40 raskolnikov>
#

"""
  User editing views.
"""

from functools import partial
import datetime, random, hashlib

from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _
from django.core.urlresolvers import reverse
from django.core.mail import send_mail
from django.contrib.auth.decorators import login_required
from django.contrib.auth import forms as auth_forms
from django.contrib import auth
from core.views import request_template_view, post_form_view
from core.forms import MixFormsHack, ExtendForm
from core.util import mixin
import forms
from models import UserProfile
from django.contrib import messages

import settings

CONFIRM_EMAIL_SENDER  = "accounts@yaas.com"
CONFIRM_EMAIL_SUBJECT = _("Confirm your account at YAAS!")
CONFIRM_EMAIL_BODY    = _("""
Hello, %(username)s, and thanks for signing up for an account!

To activate your account, click this link within 48 hours:

%(confirm_url)s
""")


def generate_activation_key (new_user):
    salt = hashlib.sha1 (str (random.random ())).hexdigest ()[:5]
    return hashlib.sha1 (salt + new_user.username).hexdigest ()


def generate_key_expires ():
    return datetime.datetime.now () + datetime.timedelta (2)


@request_template_view
def confirm (request, activation_key):
    if request.user.is_authenticated ():
        return 'user-confirm.django', { 'confirm_has_account' : True }
    
    user_profile = get_object_or_404 (UserProfile,
                                      activation_key = activation_key)
    if user_profile.key_expires < datetime.datetime.today():
        return 'user-confirm.django', {'confirm_expired': True} 

    user_account = user_profile.user
    user_account.is_active = True
    user_account.save ()
    return 'user-confirm.django', {'confirm_ok': True}


@request_template_view
def register (request):
    """
    TODO: Adapt to the new generic form API. The only problem is the
    anti-authentication check in the begining.
    """
    
    if request.user.is_authenticated ():
        return 'user-register.django', { 'has_account' : True }
    
    if request.method == 'POST':
        form = forms.RegisterForm (request.POST)
        if form.is_valid ():
            new_user       = form.save ()
            activation_key = generate_activation_key (new_user);
            key_expires    = generate_key_expires ()
            new_profile    = UserProfile (user           = new_user,
                                          activation_key = activation_key,
                                          key_expires    = key_expires)
            new_profile.save ()
            
            send_mail (CONFIRM_EMAIL_SUBJECT,
                       CONFIRM_EMAIL_BODY % {
                           'username'    : new_user.username,
                           'confirm_url' : (
                               settings.SITE_URL +
                               reverse ('user.views.confirm',
                                        args = [new_profile.activation_key])) },
                       CONFIRM_EMAIL_SENDER,
                       [ new_user.email ])

            return 'user-register.django', { 'register_ok': True }
    else:
        form = forms.RegisterForm ()
    
    return 'user-register.django', { 'register_form': form }


@request_template_view
def detail (request, username = None):
    form = create_edit_form (request, False, username)
    return 'user-detail.django', { 'object' : form.forms [0].instance,
                                   'form'   : form }

@post_form_view (partial (mixin (auth_forms.AuthenticationForm, ExtendForm),
                          request = None),
                 force_auto_bind = True,
                 extra_context = { 'form_header' : _('User login'),
                                   'form_submit' : _('Log in') })
def login (request, form):
    """
    TODO: It seems that the cookies check in AuthenticationForm is
    broken and so we are not passing the request object.
    """
    auth.login (request, form.get_user ())
    return [ 'user.views.detail' ], {}


@login_required
def logout (request):
    auth.logout (request)
    messages.info (request, _('Succesfully logged out.'))
    return redirect ('/')


def create_edit_form (request, bind, username = None):
    """
    TODO: Improve post_form_view for model related forms.
    """
    if username is None:
        user = request.user
    else:
        user = get_object_or_404 (User, username = username)
    profile = user.profile
    return MixFormsHack (
        forms.UserForm (request.POST, request.FILES, instance=user) if bind else \
        forms.UserForm (instance = user),
        forms.UserProfileForm (request.POST, request.FILES, instance = profile) \
        if bind else forms.UserProfileForm (instance = profile))


@login_required
@post_form_view (create_edit_form,
                 extra_context = { 'form_header' : _('Edit user'),
                                   'form_submit' : _('Apply changes') })
def edit (request, form):
    form.save ()
    return [ 'user.views.detail' ], {}

ExtendedPasswordChangeForm = mixin (auth_forms.PasswordChangeForm, ExtendForm)

def create_password_change_form (request, bind, username = None):
    if username is None:
        user = request.user
    else:
        user = get_object_or_404 (User, username = username)
    return ExtendedPasswordChangeForm (user, request.POST, request.FILES) \
           if bind else ExtendedPasswordChangeForm (user)

@login_required
@post_form_view (create_password_change_form,
                 extra_context = { 'form_header' : _('Change password'),
                                   'form_submit' : _('Apply changes') })
def change_password (request, form):
    form.save ()
    return [ 'user.views.detail' ], {}
