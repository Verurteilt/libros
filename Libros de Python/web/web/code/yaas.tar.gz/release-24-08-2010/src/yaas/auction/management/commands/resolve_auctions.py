#
#  File:       resolve_auctions.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sat Aug 14 21:22:30 2010
#  Time-stamp: <2010-08-23 00:46:18 raskolnikov>
#

"""
  Resolved expired auctions that have not yet been resolved.
"""

from django.core.management.base import BaseCommand
from django.core.mail import send_mass_mail
from django.utils.translation import ugettext_lazy as _
from auction.models import Auction
from user.models import User
from operator import attrgetter
from django.core.urlresolvers import reverse
from datetime import datetime
import logging

RESOLUTION_EMAIL_SENDER  = "accounts@yaas.com"
RESOLUTION_EMAIL_SUBJECT = _("Confirm your account at YAAS!")
RESOLUTION_EMAIL_BODY    = _("""
Hello!

You are reciving this email because you participated in the online
auction for %(auction_name)s.

The auction has finished and been resolveld with the result being
that %(result)s.

You can check the auction here:
%(auction_url)s

Thanks a lot,

The YAAS staff.
""")


def resolve_auction (auction):
    if auction.resolved or not auction.has_expired:
        return False

    logging.info (_('Resolving auction %s') % str (auction.pk))
    
    send_mass_mail (
        [ (RESOLUTION_EMAIL_SUBJECT,
           RESOLUTION_EMAIL_BODY % {
               'auction_name' : auction.name,
               'auction_url'  : reverse ('auction.views.detail', None,
                                         (auction.id, )),
               'result'       : ((auction.highest_bid.who and
                                  (_('The winner is %s.') %
                                   auction.highest_bid.who.username)) or
                                 _('Nobody has bid in this auction!'))
               },
           RESOLUTION_EMAIL_SENDER,
           (receiver,) )
          for receiver in 
           [auction.owner.email] +
          map (attrgetter ('email'),
               User.objects.filter (bid__auction = auction).distinct ()) ])

    auction.resolved = True
    auction.save ()
    
    return True


def resolve_all_auctions ():
    now = datetime.now ()
    
    logging.info (_('Resolving all auctions on %s ...') % str (now))
    map (resolve_auction,
         Auction.objects.filter (finishes_on__lt = now,
                                 resolved        = False,
                                 banned          = False))


class Command (BaseCommand):

    help = 'Resolved expired auctions that have not yet been resolved.'
    requires_model_validation = True
    
    def handle (self, *args, **options):
        resolve_all_auctions ()
