#
#  File:       urls.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sat Jun 26 18:19:15 2010
#  Time-stamp: <2010-08-20 20:23:05 raskolnikov>
#

"""
  Urls for the auctions application.
"""

from django.conf.urls.defaults import *

urlpatterns = patterns (
    '',
    (r'^test/generate$', 'auction.views.test_generate'),
    (r'^detail/(\d+)$',  'auction.views.detail'),
    (r'^bid/(\d+)$',     'auction.views.bid'),
    (r'^search$',        'auction.views.search'),
    (r'^create$',        'auction.views.create'),
    (r'^ban/(\d+)$',     'auction.views.ban'),
    (r'^unban/(\d+)$',   'auction.views.unban'),
)
