#
#  File:       tests.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 16 15:03:03 2010
#  Time-stamp: <2010-08-23 01:05:55 raskolnikov>
#

"""
  Tests of the main site.
"""

from django.test import TestCase

