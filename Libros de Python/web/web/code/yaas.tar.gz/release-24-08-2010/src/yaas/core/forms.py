#
#  File:       forms.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sat Aug 14 17:36:56 2010
#  Time-stamp: <2010-08-22 18:11:36 raskolnikov>
#

"""
  Generic forms and form utilities.
"""

from django.utils.encoding import force_unicode
from django import forms
from django.forms import fields
from django.core import validators
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ugettext as __
from django.utils import http
from django.forms.util import ErrorList
from django.utils.safestring import mark_safe, mark_for_escaping
from django.template import TemplateSyntaxError
from operator import and_, or_, add
from util import union_in, identity
from django.utils import formats

class MixFormsHack (object):
    """
    This hackish class comes in very handy when one wants to combine
    several forms into one. For example, when one has extended a third
    party model with a 1-to-1 relationship (like User and
    UserProfile).
    """
    
    need_join_output = ['as_url_args', 'as_hidden', 'as_table', 'as_div',
                        'as_ex_table', 'as_detail_table']

    combiner = union_in (dict ([ (x, add) for x in need_join_output ]), {
        'is_valid'     : and_,
        'is_multipart' : or_,
        'save'         : identity
    })

    def __init__ (self, *forms, **k):
        super (MixFormsHack, self).__init__ (**k)
        self.forms = forms
        
    def __getattr__ (self, name):
        try:
            val = getattr (self.forms [0], name)
            if name in self.combiner:
                def wrapper (*a, **k):
                    return reduce (self.combiner [name],
                        [ getattr (x, name) (*a, **k) for x in self.forms ])
                return wrapper
            return val
        except IndexError:
            pass


class ExtendForm (forms.BaseForm):

    with_sep    = True
    image_width = '400'
    
    def as_url_args (self):
        return http.urlencode (dict (filter (lambda (x,y): y,
                                             self.cleaned_data.iteritems ())))
    
    def as_hidden (self):
        assert self.is_bound
        try:
            output = []
            for name in self.fields.iterkeys ():
                f = self [name]
                # HACK see auctions.views.CreateLogic.process_confirm
                if isinstance (f.field, fields.ImageField) and f.data:
                    output.append ('<input type=hidden name="%s_name" value="%s"/>'
                                   % (name, f.data.name))
                output.append (f.as_hidden ())
        except Exception, e:
            raise TemplateSyntaxError (repr (e))
        return mark_safe (u'\n'.join (output))
    
    def as_div (self):
        return mark_safe ((u'<div class="form">%s</div>' + (
            '<hr class="form-sep"/>' if self.with_sep else '')) %
                          ''.join (
            [ mark_safe (u'<div class="form-element%s">'
              '<div class="form-label">%s:</div>'
              '<div class="form-input">%s</div>'
              '<div class="form-errors">%s</div></div>') %
              ("-with-error" if n in self.errors else "",
               mark_for_escaping (f.label),
               mark_for_escaping (self [n]),
               self.errors.get (n, ''))
              for n, f in
              self.fields.iteritems () ]))

    def as_ex_table (self,
                     renderer = mark_for_escaping, # TODO: Use localize?
                     mark_required = True):
        required_mark = u'<span class="form-required">*</span>'
        return mark_safe ((u'<div class="form-top-errors">' +
                           force_unicode (self.non_field_errors ())
                           + u'</div><table class="form">%s' +
                          (('<td class="form-notice">' + required_mark + 
                          __(u'Required fields.') + u'</td>'
                           '<td></td><td></td>') if mark_required else u'') +
                          '</table><hr class="form-sep"/>') % u''.join (
            [ mark_safe (u'<tr class="form-element%s">'
              '<td class="form-label">%s:%s</td>'
              '<td class="form-input">%s</td>'
              '<td class="form-errors">%s</td></tr>') %
              (u'-with-error' if n in self.errors else u'',
               mark_for_escaping (f.label),
               required_mark if mark_required and f.required else '',
               renderer (self [n]),
               self.errors.get (n, u''))
              for n, f in
              self.fields.iteritems () ])) 
      
    def as_detail_table (self):
        try:
            return self.as_ex_table (renderer      = self.render_detail_field,
                                     mark_required = False)
        except Exception, e:
            raise TemplateSyntaxError (repr (e))
    
    def render_detail_field (self, f):
        if self.is_bound:
            data = f.data
        else:
            data = f.form.initial.get (f.name, f.field.initial)
        if callable (data):
            data = data ()
        # HACK see auctions.views.CreateLogic.process_confirm
        if isinstance (f.field, fields.ImageField) and data:
            return '<a href="%s"><img style="max-width:%s px" src="%s"/></a>' % \
                   (data.url, self.image_width, data.url)
        return mark_for_escaping (unicode (formats.localize (data)))


validate_alphanum = validators.RegexValidator (r'^\w+$')


def validate_unique (model, field, exclude_pk = None):
    def validator (field_data):
        try:
            obj = model.objects.get (** { field : field_data })
        except model.DoesNotExist:
            return field_data
        if obj.pk == exclude_pk:
            return field_data
        raise validators.ValidationError (
            _('The %(fieldname)s "%(fielddata)s" is already taken.') %
            { 'fieldname' : field, 'fielddata': field_data })
    return validator


def clean_repeat (this_field, other_field, error = None):
    if error is None:
        error = _("Fields %(first)s and %(second)s must match.") % \
            { 'first' : this_field, 'second' : other_field }    
    def cleaner (form):
        this  = form.cleaned_data.get (this_field, "")
        other = form.cleaned_data.get (other_field, "")
        if this != other:
            raise forms.ValidationError (error)
        return this
    return cleaner


class TestDataGeneratorForm (forms.Form, ExtendForm):

    num_objects = forms.IntegerField (
        label       = _('Number of objects to generate'),
        required    = True,
        initial     = 20,
        min_value   = 1)


class FormViewLogic (object):
    """
    See core.views.post_form_view.
    """
    
    template_name = 'core-form.django'
    extra_context = {}
    need_confirm  = False

    def make_form (self, request, *a, **k):
        pass

    def make_bound_form (self, request, *a, **k):
        pass

    def process_form (self, request, form, *a, **k):
        return [ form.save ().get_absolute_url () ], {}
    
    def process_confirm (self, request, form = None, *a, **k):
        pass

    def _make_form (self, request, bind = False, *a, **k):
        return self.make_bound_form (request, *a, **k) if bind else \
               self.make_form (request, *a, **k)


class DivErrorList (ErrorList):
    """
    Not used anymore, this was used when we where showing errors as
    divs...
    """
    
    def __unicode__ (self):
        return self.as_divs ()

    def as_divs (self):
        if not self:
            return u''
        return u'<div class="form-errors">%s</div>' % ''.join (
            [ u'<div class="form-error">%s</div>' % e for e in self ])

