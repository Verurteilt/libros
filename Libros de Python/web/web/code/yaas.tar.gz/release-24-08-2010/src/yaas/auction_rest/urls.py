#
#  File:       urls.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Mon Aug 16 12:29:54 2010
#  Time-stamp: <2010-08-19 16:46:12 raskolnikov>
#

"""
  REST api urls.
"""

from django.conf.urls.defaults import *
from views import AuctionRest

urlpatterns = AuctionRest.urlpatterns ()
