#
#  File:       models.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 16 15:01:42 2010
#  Time-stamp: <2010-06-23 16:32:31 raskolnikov>
#

"""
  Main models of the site.
"""

from django.db import models
from django.contrib.auth.models import User
