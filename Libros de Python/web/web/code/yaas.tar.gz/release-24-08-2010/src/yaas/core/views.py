#
#  File:       views.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 16 15:03:30 2010
#  Time-stamp: <2010-08-22 23:11:44 raskolnikov>
#

"""
  Main views of the site.
"""

from functools import partial, wraps

from django import shortcuts
from django.template import RequestContext, loader
from django.views.generic import simple
from forms import TestDataGeneratorForm
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _
from core.util import union_in, identity
from django.core.urlresolvers import reverse
from django import forms
from django import http

index = partial (simple.direct_to_template, template = 'index.django')


def generic_test_data_generator (request,
                                 template  = 'core-test-gen.django',
                                 generator = None):
    generate_ok = False
    form = None
    num_objects = 0
    if request.method == 'POST':
        form = TestDataGeneratorForm (request.POST)
        if form.is_valid ():
            num_objects = form.cleaned_data ['num_objects'] 
            generator (num_objects)
            messages.info (request,
                           _('Correctly generated %s objects.') % num_objects)
    else:
        form = TestDataGeneratorForm ()
    
    return shortcuts.render_to_response (
        template,
        { 'generate_ok'   : generate_ok,
          'generate_num'  : num_objects,  
          'generate_form' : form },
        context_instance = RequestContext (request))


def request_render_to_response (template_name,
                            request,
                            data_dictionary = {}):
    return shortcuts.render_to_response (
        template_name,
        data_dictionary,
        context_instance = RequestContext (request))


def lazy_redirect (*a, **k):
    return lambda: shortcuts.redirect (*a, **k)


def lazy_reverse (*a, **k):
    return lambda: reverse (*a, **k)


def request_template_view (view):
    @wraps (view)
    def new_view (request, *a, **k):
        ret = view (request, *a, **k)
        if callable (ret):
            return ret ()
        else:
            tpl, data = ret
            return request_render_to_response (tpl, request, data)
    return new_view


def make_form_view_from_logic (logic):
    return post_form_view (logic._make_form,
                           template_name = logic.template_name,
                           need_confirm  = logic.need_confirm,
                           pre_confirm   = logic.process_confirm,
                           extra_context = logic.extra_context) (
        logic.process_form)


def post_form_view (form_cls,
                    template_name   = 'core-form.django',
                    extra_context   = {},
                    need_confirm    = False,
                    pre_confirm     = identity,
                    force_auto_bind = False):
    """
    For template writers, 'form_confirmed' can have 3 values:
      - 'true':  Save the form
      - None:    Show the confirm-yes-no question
      - 'false': Show the form but bounded to the data sent by POST.
    """
    
    form_as_view = not force_auto_bind and \
                   not isinstance (form_cls, forms.BaseForm)
    def decorator (view):
        @wraps (view)
        @request_template_view
        def actual_view (request, *a, **k):
            form_confirmed    = None
            form_show_confirm = False
            form              = None
            form_context      = extra_context
            
            if request.method == 'POST':
                form = form_cls (request, True, *a, **k) if \
                       form_as_view else form_cls (data  = request.POST,
                                                   files = request.FILES)
                form_confirmed = request.POST.get ('form_confirmed')
                if form.is_valid ():
                    if not need_confirm or form_confirmed == "true":
                        ra, rk = view (request, form, *a, **k)
                        return lazy_redirect (*ra, **rk) 
                    elif form_confirmed is None:
                        pre_confirm (request, form, *a, **k)
                        form_show_confirm = True
            else:
                form = form_cls (request, False, *a, **k) if \
                       form_as_view else form_cls ()
            return template_name, union_in ({
                'form'              : form,
                'form_show_confirm' : form_show_confirm
                }, form_context)
        return actual_view
    return decorator


def page_not_found (request, template_name = 'error-404.django'):
    """
    Override default 404 error for consistency.
    """
    t = loader.get_template (template_name)
    return http.HttpResponseNotFound (
        t.render (RequestContext (request, { 'request_path': request.path })))

def server_error (request, template_name = 'error-500.django'):
    """
    Override default 500 error for consistency.
    """
    t = loader.get_template (template_name)
    return http.HttpResponseServerError (
        t.render (RequestContext (request, {})))
