#
#  File:       tests.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sun Aug 22 18:36:13 2010
#  Time-stamp: <2010-08-23 00:56:42 raskolnikov>
#

"""
  Tests for the auction application.

  Again, we try to ommit those tests that are more or less trivial
  because they are mostly dependent from Django, such as form
  validation.
"""

import models
from django.test import TestCase
from django.test.client import Client
from django.core import mail
from management.commands.resolve_auctions import (resolve_auction,
                                                  resolve_all_auctions)
from decimal import Decimal
from datetime import timedelta, datetime
from operator import attrgetter
from user.models import User
from itertools import chain


class AuctionCreateTest (TestCase):

    fixtures = [ 'users.json' ]
    
    def setUp (self):
        c = self.client = Client ()
        c.login (username = 'root', password = 'root')
    
    def test_create_confirm_no (self):
        self.response = self.client.post ('/auction/create', {
            'name' : 'test_name',
            'description' : 'test_description',
            'minimum_bid' : '10.00',
            'finishes_on' : str (datetime.now ().replace (microsecond = 0) +
                                 timedelta (days = 4)),
            'form_confirmed' : 'false' })
        self.assertTrue (self.response.content.find ('value="Create auction"')>=0)
        self.assertRaises (Exception, models.Auction.objects.get,
                           name = 'test_name')
        
    def test_create_confirm (self):
        self.response = self.client.post ('/auction/create', {
            'name' : 'test_name',
            'description' : 'test_description',
            'minimum_bid' : '10.00',
            'finishes_on' : str  (datetime.now ().replace (microsecond = 0)
                                  + timedelta (days = 4)) })
        self.assertTrue (self.response.content.find ('form-confirm-question')>=0)
        self.assertRaises (Exception, models.Auction.objects.get,
                           name = 'test_name')

    def test_create_create (self):
        self.response = self.client.post ('/auction/create', {
            'name' : 'test_name',
            'description' : 'test_description',
            'minimum_bid' : '10.00',
            'finishes_on' : str (datetime.now ().replace (microsecond = 0)
                                 + timedelta (days = 4)),
            'form_confirmed' : 'true'}, follow = True)
        self.assertTrue (self.response.content.find ('Auction created')>=0)
        a = models.Auction.objects.get (name = 'test_name')
        # Test the signal that maintains the invariant that
        # highest_bid.ammount = a.minimum_bid when no user has bid
        # (useful for searching, read comment in auction.models.Bid)
        self.assertEquals (a.minimum_bid, a.highest_bid.ammount)


class AuctionBidTest (TestCase):

    fixtures = [ 'auctions.json' ]

    def test_bid_own_auction_error (self):
        c = Client ()
        c.login (username = 'root', password = 'root')
        pk = models.Auction.objects.get (name = 'no_bid').pk
        r = c.post ('/auction/bid/' + str (pk), { 'ammount' : '40.0' },
                    follow = True)
        self.assertTrue (r.content.find ('can not bid in your own auctions')>=0)
        self.assertEquals (
            models.Auction.objects.get (name = 'no_bid').highest_bid.who, None)

    def test_bid_own_bid_error (self):
        c = Client ()
        c.login (username = 'aurora', password = 'aurora')
        pk = models.Auction.objects.get (name = 'with_bid').pk
        r = c.post ('/auction/bid/' + str (pk), { 'ammount' : '60' },
                    follow = True)
        self.assertTrue (r.content.find ('already made the highest bid')>=0)
        self.assertEquals (
            models.Auction.objects.get (name='with_bid').highest_bid.ammount,
            Decimal ('40'))

    def test_bid_expired_error (self):
        c = Client ()
        c.login (username = 'aurora', password = 'aurora')
        pk = models.Auction.objects.get (name = 'no_bid_expired').pk
        r = c.post ('/auction/bid/' + str (pk), { 'ammount' : '60' },
                    follow = True)
        
        self.assertTrue (r.content.find ('deadline is over')>=0)
        self.assertEquals (
            models.Auction.objects.get (name='no_bid_expired').highest_bid.who,
            None)

    def test_bid_ok (self):
        c = Client ()
        c.login (username = 'encarna', password = 'encarna')
        pk = models.Auction.objects.get (name = 'with_bid').pk
        r = c.post ('/auction/bid/' + str (pk), { 'ammount' : '60' },
                    follow = True)
        self.assertTrue (r.content.find ('bid have been registered')>=0)
        self.assertEquals (
            models.Auction.objects.get (name='with_bid').highest_bid.who.username,
            'encarna')
        self.assertEquals (
            models.Auction.objects.get (name='with_bid').highest_bid.ammount,
            Decimal ('60'))
        

class AuctionResolveTest (TestCase):

    fixtures = [ 'auctions.json' ]

    def test_resolve_all (self):
        resolved = models.Auction.objects.filter (resolved = True)
        self.assertEquals (resolved.count (), 0)
        resolve_all_auctions ()
        resolved = models.Auction.objects.filter (resolved = True)
        self.assertEquals (resolved.count (), 2)

    def do_test_resolve_one (self, auction):
        self.assertTrue (auction.has_expired)
        self.assertFalse (auction.resolved)
        resolve_auction (auction)
        receivers = [ auction.owner.email ] + \
                    map (attrgetter ('email'),
                         User.objects.filter (bid__auction = auction).distinct ())
        self.assertEqual (len (receivers), len (mail.outbox))
        self.assertEqual (set (receivers), set (chain.from_iterable (
            [x.to for x in mail.outbox])))
        self.assertTrue (models.Auction.objects.get (pk = auction.pk))

    def test_resolve_with_bid_expired (self):
        auction = models.Auction.objects.get (name = 'with_bid_expired') 
        self.do_test_resolve_one (auction)

    def test_resolve_no_bid_expired (self):
        auction = models.Auction.objects.get (name = 'no_bid_expired') 
        self.do_test_resolve_one (auction)


class AuctionBanTest (TestCase):

    fixtures = [ 'auctions.json' ]

    def test_ban_staff (self):
        c = Client ()
        c.login (username = 'aurora', password = 'aurora')
        r = c.post ('/auction/ban/1', {}, follow = True)
        self.assertEqual (r.status_code, 404)

    def test_ban_ok (self):
        c = Client ()
        c.login (username = 'root', password = 'root')
        r = c.post ('/auction/ban/1', {}, follow = True)
        self.assertTrue (r.content.find ('Auction banned')>=0)
        self.assertEqual (r.status_code, 200)
        self.assertEqual (models.Auction.objects.get (pk = 1).banned, True)
        

    def test_unban_ok (self):
        c = Client ()
        c.login (username = 'root', password = 'root')
        self.assertEqual (models.Auction.objects.get (name='banned').banned, True)
        r = c.post ('/auction/unban/' +
                    str (models.Auction.objects.get (name='banned').pk),
                    {}, follow = True)
        self.assertEqual (models.Auction.objects.get (name='banned').banned, False)
        self.assertTrue (r.content.find ('Auction unbanned')>=0)
        self.assertEqual (r.status_code, 200)



class AuctionGeneratorTest (TestCase):

    fixtures = [ 'users.json' ]
    
    def setUp (self):
        c = self.client = Client ()
        c.login (username = 'root', password = 'root')
        self.request = c.post ('/auction/test/generate', { 'num_objects' : 50 })

    def test_heterogeneity (self):
        """ This is actually a proabilistic test but it should pass
        unless the random number generator are very weird. We can
        actually think about making the generator not that random...

        NOTE: The setUp() for this test is slow, so we merged
        test_count here and others here."""
        all_auctions = models.Auction.objects.all ()
        with_soft_deadline = models.Auction.objects.filter (soft_deadline = True)
        with_no_bid = filter (lambda x: x.highest_bid.who, all_auctions)
        with_expired = filter (lambda x: x.has_expired, all_auctions)

        self.assertEquals (all_auctions.count (), 50)
        self.assertTrue (with_soft_deadline.count () > 0)
        self.assertTrue (with_soft_deadline.count () < 50)
        self.assertTrue (len (with_no_bid) > 0)
        self.assertTrue (len (with_no_bid) < 50)
        self.assertTrue (len (with_expired) > 0)
        self.assertTrue (len (with_expired) < 50)

        
