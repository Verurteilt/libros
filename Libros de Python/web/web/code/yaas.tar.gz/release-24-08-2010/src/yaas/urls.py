#
#  File:       urls.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 16 15:00:00 2010
#  Time-stamp: <2010-08-22 00:53:54 raskolnikov>
#

"""
  Main site URL patterns.
"""

from django.conf.urls.defaults import *
from django.contrib import admin
import settings
from core import views

admin.autodiscover ()

urlpatterns = patterns (
    '',
    (r'^media/(?P<path>.*)$', 'django.views.static.serve',
     {'document_root': settings.MEDIA_ROOT,
      'show_indexes': True}),
    
    (r'^admin/doc/',      include ('django.contrib.admindocs.urls')),
    (r'^i18n/',           include ('django.conf.urls.i18n')),
    
    (r'^admin/',          include (admin.site.urls)),
    
    (r'^user/',           include ('yaas.user.urls')),
    (r'^auction/',        include ('yaas.auction.urls')),
    (r'^api/v1/',         include ('yaas.auction_rest.urls')),

    (r'^$',               'yaas.core.views.index'),
)

handler404 = views.page_not_found
handler500 = views.server_error
