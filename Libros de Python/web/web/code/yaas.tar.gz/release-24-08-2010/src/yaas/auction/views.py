#
#  File:       views.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sat Jun 26 18:13:22 2010
#  Time-stamp: <2010-08-22 19:07:29 raskolnikov>
#

"""
  Views for the auctions application.
"""

from functools import partial
from core import views
import core.forms
from core.util import get_as
from user.models import User
from models import Auction, Bid, BidError, do_bid, can_bid
from generator import generate_random_fixture
from django.views.generic import list_detail, create_update
from django.utils.translation import ugettext_lazy as _
from django.core.urlresolvers import reverse
from django.http import Http404
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Max
from django.contrib import messages
from django.core.mail import send_mass_mail
from operator import attrgetter
import forms

test_generate = user_passes_test (lambda u: u.is_staff) (
    partial (views.generic_test_data_generator,
             generator = generate_random_fixture))

        
def get_search_query_set (request):
    can_ban = request.user and request.user.has_perm ('can_ban_auction')
    
    name     = request.GET.get ('name',       '')
    desc     = request.GET.get ('desc',       '')
    order    = request.GET.get ('order',      '') 
    ascdes   = request.GET.get ('ascdes',     '') 
    resolved = request.GET.get ('resolved',   '')
    begin    = get_as (request.GET, int, 'begin', None)
    end      = get_as (request.GET, int, 'end',   None)

    query = (Auction.objects.all () if can_ban else \
             Auction.objects.filter (banned = False)).filter (
        name__icontains        = name,
        description__icontains = desc)
    if not resolved:
        query = query.filter (resolved = False)
    
    total = len (query)
    
    if order == 'min_bid':
        query = query.annotate (min_bid = Max ('bid__ammount'))

    if not order in dict (forms.search_order):
        order = 'name'
    if ascdes == 'des':
        order = '-' + order
    
    query = query.order_by (order)

    if begin is not None:
        query = query [begin:]
    if end is not None:
        query = query [:end]

    return query, total


def search (request):
    form         = forms.SearchForm (request.GET)
    query, total = get_search_query_set (request)
    nres         = get_as (request.GET, int, 'nres', 10)
    
    return list_detail.object_list (request,
                                    queryset      = query,
                                    template_name = 'auction-search.django',
                                    paginate_by   = nres,
                                    extra_context = { 'search_form'  : form,
                                                      'search_total' : total })

@views.request_template_view
def detail (request, auction_id = None, extra_content = {}):
    can_ban  = request.user and request.user.has_perm ('can_ban_auction')
    queryset = Auction.objects.all () if can_ban else \
               Auction.objects.filter (banned = False)
    auction  = get_object_or_404 (queryset, pk = auction_id)
    bid_form = None
    if can_bid (request.user, auction):
        bid_form = forms.BidForm (instance = Bid (
            auction = auction,
            ammount = auction.next_bid))
    auction_form = forms.AuctionForm (instance = auction)
    return 'auction-detail.django', { 'bid_form'     : bid_form,
                                      'auction_form' : auction_form,
                                      'auction'      : auction }


class CreateLogic (core.forms.FormViewLogic):
    need_confirm  = True
    extra_context = {
        'form_header'           : _('Create new auction'),
        'form_confirm_question' : _('Are you sure that you want to create '
                                    'this auction?'),
        'form_submit'           : _('Create auction'),
        }

    def make_form (self, request):
        return forms.AuctionForm (default_owner = request.user)

    def make_bound_form (self, request):
        return forms.AuctionForm (request.POST, request.FILES,
                                  default_owner = request.user)
    
    def process_confirm (self, request, form):
        """
        There is a HACK here that works in combination with
        ExtendForm. The idea is that in a 2-step form (with
        confirmation) it is not possible to save the picture
        directly.
        
        What we do is to save it here anyway (in the first step) and
        substitute the file for this one. Then the hacked ExtendForm
        will create an extra hidden field '_name' with the location of
        the file. Then in the last step we retrieve that and use it in
        the final object stored in the database.
        """
        if form ['picture'].data:
            a = form.save (commit = False)
            a.picture.save (request.POST.get ('picture'),
                            form ['picture'].data,
                            save = False)
            request.FILES ['picture'] = a.picture
    
    def process_form (self, request, form, *a, **k):
        a = form.save (commit = False)
        pic = request.POST.get ('picture_name')
        if pic:
            a.picture = pic
        a.save ()
        messages.info (request, _('Auction created successfully.'))
        return [ a.get_absolute_url () ], {}


create = login_required (views.make_form_view_from_logic (CreateLogic ()))


@login_required
def set_ban (request, auction_id = None, new_value = True):
    if not request.user.has_perm ('can_ban_auction') or \
           not request.method == 'POST':
        raise Http404

    auction = get_object_or_404 (Auction, pk = auction_id)
    auction.banned = new_value
    auction.save ()
    messages.info (request,
                   _('Auction banned successfully.') if new_value else
                   _('Auction unbanned successfully.'))

    send_mass_mail (
        [(BANNING_EMAIL_SUBJECT,
          (BANNING_EMAIL_BODY if new_value else UNBANNING_EMAIL_BODY) %
          { 'auction_name' : auction.name },
          BANNING_EMAIL_SENDER,
          (receiver,))
         for receiver in
         [auction.owner.email] +
         map (attrgetter ('email'),
              User.objects.filter (bid__auction = auction).distinct ()) ])

    
    return detail (request, auction_id)


ban   = partial (set_ban, new_value = True)

unban = partial (set_ban, new_value = False)


@login_required
def bid (request, auction_id = None):
    auction = get_object_or_404 (Auction, pk = auction_id)

    if request.method != 'POST':
        messages.error (request, _('Invalid request.'))
    else:
        form = forms.BidForm (request.POST)
        if not form.is_valid ():
            messages.error (request, _('Invalid request: Wrong data.'))
        else:
            ammount = form.cleaned_data ['ammount']
            try:
                do_bid (auction, ammount, request.user)
                messages.info (request, _("Your bid have been registered."))
            except BidError, e:
                messages.error (request, str (e))
                
    return detail (request, auction_id)


@login_required
def create_old (request):
    """
    Former implementation of the creation. Sadly, generic views don't
    support the confirmation step that is required in the
    requirements.
    """
    return create_update.create_object (
        request,
        form_class     = forms.make_auction_form (request),
        template_name  = 'auction-create-edit.django',
        extra_context  =
        { 'create_or_edit'     : reverse ('auction.views.create'),
          'create_or_edit_txt' : _('Create') })


@login_required
def edit_old (request, auction_id):
    """
    Our first implementation using Django generic views included this
    edit function. However, we later discovered that this makes no
    sense. Read the documentation for the rationale.
    """
    if request.user != get_object_or_404 (Auction,
                                          pk = auction_id,
                                          banned = False).owner:
        raise Http404
    
    return create_update.update_object (
        request,
        model          = Auction,
        object_id      = auction_id,
        template_name  = 'auction-create-edit.django',
        login_required = True,
        extra_context  =
        { 'create_or_edit'     : reverse ('auction.views.edit',
                                          None, (auction_id,)),
          'create_or_edit_txt' : _('Edit') })


BANNING_EMAIL_SENDER  = "accounts@yaas.com"
BANNING_EMAIL_SUBJECT = _("Confirm your account at YAAS!")
BANNING_EMAIL_BODY    = _("""
Dear customer,

You are reciving this email because you participated in the online
auction for %(auction_name)s in YAAS.

The auction have been banned because it does violate the terms of
service of the web page, and therefore you can not find it anymore.

If you have furder allegations contact the administrators.

Sorry for the inconvenience,

The YAAS staff.
""")
UNBANNING_EMAIL_BODY    = _("""
Dear customer,

You are reciving this email because you participated in the online
auction for %(auction_name)s in YAAS.

The auction was banned by the administrators because of doubts about
the conformance of the terms of service but we have found that it
satisfies them. Therefore the auction is now active again and you can
continue participating into it.

Sorry for the inconvenience,

The YAAS staff.
""")
