#
#  File:       rest.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Thu Aug 19 12:05:54 2010
#  Time-stamp: <2010-08-23 20:29:08 raskolnikov>
#

"""
  Utils to implement a RESTful api.
"""

from django.conf.urls.defaults import patterns
from core.util import get_as
from django import http
from django.contrib import auth
from serialize import serialize_data, deserialize_data
from email.utils import formatdate, parsedate
from datetime import datetime
import re
import time

formatdate = formatdate
parsedate  = parsedate

http_methods    = [ 'GET', 'PUT', 'POST', 'DELETE', 'HEAD', 'OPTIONS' ]
http_methods_re = r'|'.join (map (str.lower, http_methods))

format_mimetypes = {
    'json' : 'application/json',
    'yaml' : 'application/yaml',
    'xml'  : 'application/xml'
    }

class RestException (Exception):

    def __init__ (self, *a, **k):
        super (RestException, self).__init__ (*a)
        self.__dict__.update (k)
        
    def to_http_response (self):
        response = http.HttpResponse (getattr (self, 'response', ''))
        response.status_code = 400
        return response


class RestNotModified (RestException):

    def to_http_response (self):
        return http.HttpResponseNotModified ()


class RestForbidden (RestException):

    def to_http_response (self):
        return http.HttpResponseForbidden ()


class RestUnauthorized (RestException):

    def to_http_response (self):
        response = http.HttpResponse ()
        response.status_code = 401
        if hasattr (self, 'basic_realm'):
            response ["WWW-Authenticate"] = 'Basic realm="%s"' % self.basic_realm
        return response


class RestResource (object):

    resource       = 'resource'
    default_format = 'xml'
    fmt_re         = r'xml|json|yaml'
    id_re          = r'\w+'
    
    def __init__ (self,
                  request  = None,
                  fmt      = None,
                  inst_id  = None,
                  *a, **k):
        super (RestResource, self).__init__ (*a, **k)
        self.request = request
        self.fmt     = fmt or self.default_format
        self.inst_id = inst_id
    
    def serialize (self, data, *a, **k):
        indent = get_as (self.request.GET, int, 'indent')
        return serialize_data (self.fmt, data, indent = indent, *a, **k)

    def deserialize (self, string):
        return deserialize_data (self.fmt, string)
    
    @classmethod
    def urlpatterns (cls):
        inst_ops = find_operations (cls, 'instance')
        cont_ops = find_operations (cls, 'container')
        base_re  = r'(?P<fmt>%s)/%s' % (cls.fmt_re, cls.resource)

        inst_ops_patterns = [
            (r'^%s/(?P<inst_id>%s)/%s$' % (base_re, cls.id_re, op),
             cls.dispatch_view, { 'operation' : op },
             'rest_%s_instance_%s' % (cls.resource, op))
            for op in inst_ops ]

        cont_ops_patterns = [
            (r'^%s/%s$' % (base_re, op), cls.dispatch_view,
             { 'operation' : op }, 'rest_%s_container_%s' % (cls.resource, op))
            for op in cont_ops ]

        # The order is important, containers should go before
        # instances and operations before access.
        urls  = patterns ('', *cont_ops_patterns)
        urls += patterns ('', *inst_ops_patterns)
        urls += patterns (
            '',
            (r'^%s$' % base_re, cls.dispatch_view, {},
             'rest_%s_container' % cls.resource),
            (r'^%s/(?P<inst_id>%s)$' % (base_re, cls.id_re), cls.dispatch_view,
             {}, 'rest_%s_instance' % cls.resource))
        return urls
    
    @classmethod
    def dispatch_view (cls, request, inst_id = None,
                       operation = None, fmt = None):        
        hdl_obj = cls (request = request, inst_id = inst_id, fmt= fmt)
        hdl_name = 'view%s%s%s' % (
            '_instance' if inst_id is not None else '_container',
            '_' + operation if operation else '',
            '_' + request.method.lower ())
        hdl = getattr (hdl_obj, hdl_name, None)
        if callable (hdl):
            try:
                authenticate (request)
                response = hdl ()
                response.mimetype = format_mimetypes [fmt]
                return response
            except RestException, e:
                return e.to_http_response ()
        return http.HttpResponseNotAllowed (
            find_allowed_methods (hdl_obj, hdl_name))


def find_operations (obj, receiver = 'instance'):
    prog = re.compile (r'view_%s_(\w+)_(%s)' % (receiver, http_methods_re))
    return map (lambda x: x.group (1), filter (bool, map (prog.match, dir (obj))))


def find_allowed_methods (obj, op):
    return filter (lambda x: callable (getattr (obj, op+'_'+x.lower (), None)),
                   http_methods)


def to_authorization (username, password):
    return "Basic " + ":".join ([username, password]).encode ("base64") 


def authenticate (request):
    auth_info = request.META.get ("HTTP_AUTHORIZATION", None)
    if auth_info and auth_info.startswith ("Basic "):
        basic_info = auth_info.split (" ", 1) [1]
        u, p = basic_info.decode ("base64").split (":")
        request.user = auth.authenticate (username = u, password = p)
    else:
        request.user = None
    return request


def resource_require_authenticate (view):
    def wrapper (self, *a, **k):
        if self.request.user is None:
            raise RestUnauthorized (basic_realm = self.resource)
        return view (self, *a, **k)
    return wrapper


def resource_require_permission (permission):
    def decorator (view):
        def wrapper (self, *a, **k):
            user = self.request.user
            if user is None or not user.has_perm (permission):
                raise RestUnauthorized (basic_realm = permission)
            return view (self, *a, **k)
        return wrapper
    return decorator


def check_authenticate (request, basic_realm = ''):
    if request.user is None:
        raise RestUnauthorized (basic_realm = basic_realm)


def check_permission (request, permission):
    if request.user is None or not request.user.has_perm (permission):
        raise RestForbidden (basic_realm = permission)


def check_last_modified (request, query):
    lm = get_as (request.META, parsedate,
                 "HTTP_IF_MODIFIED_SINCE", None)
    if lm:
        query.filter (time_stamp__gt = datetime (*lm [:6]))
        if query.count () == 0:
            raise RestNotModified ()
    return None


def require_authenticate (basic_realm):
    """
    Legacy decorator that can be used outside RestResource.  One
    should use resource_* decorators in RestResource methods instead.
    """
    
    def decorator (view):
        def wrapper (request, *a, **k):
            authenticate (request)
            if request.user is None:
                response = http.HttpResponseForbidden ()
                response ["WWW-Authenticate"] = 'Basic realm="%s"'%basic_realm
                return response
            return view (request, *a, **k)
        return wrapper
    return decorator
