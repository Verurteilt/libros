#
#  File:       generator.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Fri Aug 20 19:30:25 2010
#  Time-stamp: <2010-08-22 17:53:03 raskolnikov>
#

"""
  Random generator of auctions for testing purposes.
"""

from django.contrib.auth.models import User
from models import Bid, Auction, minimum_bid, maximum_bid
import random
import sys
import codecs
import re
import datetime
from functools import partial

import settings

def generate_phrase (words,
                     max_length = sys.maxint,
                     min_words  = 1,
                     max_words  = 16):
    """
    Generates nonsensical phrases :D
    """
    phrase = random.choice (words)
    times = random.randint (min_words, max_words) - 1
    while times > 0 and len (phrase) < max_length:
        phrase += ' ' + random.choice (words)
        if random.random () < .2:
            phrase += random.choice (['.', ',', ';'])
        times -= 1
    return phrase [0:max_length]

def generate_future_date (min_minutes = 1,
                          max_minutes = 60*24*365):
    return datetime.datetime.now () + generate_timedelta (min_minutes,
                                                          max_minutes)

def generate_past_date (min_minutes = 1,
                        max_minutes = 60*24*365):
    return datetime.datetime.now () - generate_timedelta (min_minutes,
                                                          max_minutes)

def generate_timedelta (min_minutes = 1,
                        max_minutes = 60*24*365):
    return datetime.timedelta (minutes = random.randint (min_minutes,
                                                         max_minutes))

def timedelta_to_minutes (td):
    return td.days * 60*24 + td.seconds / 60 + (td.microseconds / 60) / (10**6)

def generate_random_fixture (num_auctions = 50,
                             num_bids     = partial (random.normalvariate,
                                                     10, 10),
                             dict_file    = settings.DICT_FILE):
    
    with codecs.open (dict_file, "r", "utf-8") as words_file:
        all_users = User.objects.filter (is_active = True)
        words = re.findall (r'[\w\']+', words_file.read ())
        
        for i in range (0, num_auctions):
            auction_start = generate_past_date ()
            auction_end   = auction_start + generate_timedelta ()
            a = Auction (owner = random.choice (all_users),
                         name  = generate_phrase (words, 255),
                         description = generate_phrase (words, 4096, 8, 256),
                         finishes_on = auction_end,
                         created_on  = auction_start,
                         minimum_bid = str (random.uniform (1., 1000.)),
                         soft_deadline = random.random () < .5)
            a.save ()
            
            bids = num_bids () if callable (num_bids) else num_bids
            max_minutes = timedelta_to_minutes (
                datetime.datetime.now () - a.created_on)
            
            while bids > 0:
                delta = generate_timedelta (1, max_minutes)

                bid_time = a.created_on + delta
                
                min_bid  = (minimum_bid (a, bid_time) or
                            Bid (ammount = a.minimum_bid)).ammount
                max_bid  = (maximum_bid (a, bid_time) or
                            Bid (ammount = 1000000.0)).ammount
                
                b = Bid (auction    = a,
                         ammount    = str (random.uniform (float (min_bid),
                                                           float (max_bid))),
                         who        = random.choice (all_users),
                         time_stamp = bid_time)
                
                b.save ()
                bids -= 1

