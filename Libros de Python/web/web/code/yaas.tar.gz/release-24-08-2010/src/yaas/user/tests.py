#
#  File:       tests.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 23 15:47:43 2010
#  Time-stamp: <2010-08-22 18:35:37 raskolnikov>
#

"""
  Tests of the user management.

  Note that we tried to avoid testing the functionality included in
  django.contrib.auth, like login/logout, because it is already
  tested.
"""

import models
from django.test import TestCase
from django.test.client import Client
from django.core import mail

class UserRegisterFormTest (TestCase):

    fixtures = [ 'users.json' ]

    def setUp (self):
        self.client = Client ()
        self.response = self.client.post ('/user/register',
                                          { 'new_username'  : 'root',
                                            'new_password1' : 'test_pass1',
                                            'new_password2' : 'test_pass2' })
        
    def test_response_no_error (self):
        self.assertEquals (self.response.status_code, 200)

    def test_unique_user (self):
        self.assertTrue (self.response.content.find ("is already taken")>=0)

    def test_match_password (self):
        self.assertTrue (self.response.content.find ("passwords do not match")>=0)

    def test_email_required (self):
        self.assertTrue (self.response.content.find ("field is required")>=0)


class UserRegisterTest (TestCase):

    def setUp (self):
        self.client = Client ()
        self.response = self.client.post ('/user/register',
                                          { 'new_username'  : 'new_user',
                                            'new_email'     : 'new_em@il.fi',
                                            'new_password1' : 'new_pass',
                                            'new_password2' : 'new_pass' })
    
    def test_response_no_error (self):
        self.assertEquals (self.response.status_code, 200)
        self.assertTrue (self.response.content.find ("confirmation link")>=0)

    def test_user_created (self):
        user = models.User.objects.get (username = 'new_user')
        self.assertNotEqual (user, None)
        self.assertEquals (len (mail.outbox), 1)
        self.assertTrue (mail.outbox[0].body.find (user.profile.activation_key)>=0)

    def test_user_confirm (self):
        user = models.User.objects.get (username = 'new_user')
        self.assertTrue (not user.is_active)
        response = self.client.get ('/user/confirm/' + user.profile.activation_key)
        self.assertTrue (response.content.find ("correctly confirmed")>=0)
        user = models.User.objects.get (username = 'new_user')
        self.assertTrue (user.is_active)

