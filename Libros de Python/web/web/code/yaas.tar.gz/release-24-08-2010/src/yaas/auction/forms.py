#
#  File:       forms.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sat Aug 14 17:32:27 2010
#  Time-stamp: <2010-08-21 12:43:55 raskolnikov>
#

"""
  Forms of the auction service.
"""

from core.forms import ExtendForm
from models import Auction, Bid
from django.utils.translation import ugettext_lazy as _
from django import forms
from datetime import datetime, timedelta

search_order = (
    ('name'         , _('Alphabetical')),
    ('created_on'   , _('Creation date')),
    ('finishes_on'  , _('Finishing date')),
    ('min_bid'      , _('Price'))
)

search_ascdes = (
    ('asc' , _('Ascending')),
    ('des' , _('Descending'))
)


class SearchForm (forms.Form, ExtendForm):
    
    name  = forms.CharField (
        label       = _('Name contains'),
        required    = False)

    desc  = forms.CharField (
        label       = _('Description contains'),
        required    = False)

    order = forms.ChoiceField (
        label       = _('Order by'),
        choices     = search_order,
        required    = False) 
    
    ascdes = forms.ChoiceField (
        label       = _('Sort'),
        choices     = search_ascdes,
        required    = False)

    nres   = forms.ChoiceField (
        label       = 'Results per page',
        choices     = (('10',  '10'),
                       ('20',  '20'),
                       ('50',  '50'),
                       ('100', '100')),
        required    = False)


class BidForm (forms.ModelForm, ExtendForm):

    with_sep = False
    
    class Meta:
        model = Bid


class AuctionForm (forms.ModelForm, ExtendForm):
    class Meta:
        model = Auction

    default_owner = None

    def __init__ (self, *a, **k):
        self.default_owner = k.pop ('default_owner', self.default_owner)
        super (AuctionForm, self).__init__ (*a, **k)

    def clean_finishes_on (self):
        finishes_on = self.cleaned_data ['finishes_on']
        if finishes_on < datetime.now () + timedelta (hours = 48):
            raise forms.ValidationError(_("An auction must last "
                                          "at least 48 hours."))
        return finishes_on

    def save (self, commit = True, *a, **k):
        f = super (AuctionForm, self).save (commit = False, *a, **k)
        f.owner = self.default_owner
        if commit:
            f.save (commit = commit)
        return f


def make_auction_form (request):
    """
    This is kind-a inefficient but it's Django's fault for generic
    views not being so generic ;)

    TODO: Deprecated, only needed for create_old.
    """
    class NewAuctionForm (AuctionForm):
        default_owner = request.user
    return NewAuctionForm
