#
#  File:       admin.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Fri Aug 20 19:58:15 2010
#  Time-stamp: <2010-08-20 19:59:17 raskolnikov>
#

"""
  Admin interface for the Auctiona app.
"""

from django.contrib import admin
from models import Auction, Bid

class AuctionAdmin (admin.ModelAdmin): pass
class BidAdmin (admin.ModelAdmin): pass

admin.site.register (Auction, AuctionAdmin)
admin.site.register (Bid, BidAdmin)
