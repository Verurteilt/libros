#
#  File:       settings.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 16 15:18:32 2010
#  Time-stamp: <2010-08-23 12:08:33 raskolnikov>
#

"""
  Django settings file.
"""

import os
from django.utils.translation import ugettext_lazy as _

DEBUG = True
TEMPLATE_DEBUG = DEBUG

ADMINS = (
    ('Juan Pedro Bolivar Puente', 'jbolivar@abo.fi'),
)

MANAGERS = ADMINS

DATABASES = {
    'default': {
        'ENGINE'   : 'django.db.backends.sqlite3',
        'NAME'     : 'data/test-db.sqlite3',
        'USER'     : '',
        'PASSWORD' : '',
        'HOST'     : '',
        'PORT'     : '',
    }
}

# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
TIME_ZONE = 'Europe/Helsinki'
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

USE_I18N = True
USE_L10N = True

MEDIA_ROOT = os.path.join (os.path.dirname(__file__), 'media')
MEDIA_URL = 'http://127.0.0.1:8000/media/'
ADMIN_MEDIA_PREFIX = '/admin-media/'

SECRET_KEY = 't3s74y&j3(00uuc#iumc@nl&r+36!_%ga%-m$c=y3b@g2%d)=a'

TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.locale.LocaleMiddleware',
)

ROOT_URLCONF = 'yaas.urls'

TEMPLATE_DIRS = (
    os.path.join (os.path.dirname(__file__), 'tpl'),
)

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.admin',

    'yaas.core',
    'yaas.user',
    'yaas.auction',
    'yaas.auction_rest',
)

AUTH_PROFILE_MODULE = 'core.UserProfile'
LOGIN_URL = 'http://127.0.0.1:8000/user/login'
LOGIN_REDIRECT_URL = '/user/profile'

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

SITE_URL = 'http://127.0.0.1:8000'

SITE_CURRENCY = 'euro'
ALL_CURRENCY  = {
    "euro"      : (_("euro"),         u"&euro;"),
    "dollar-US" : (_("U.S. dollar"),  u"$"),
    }
CURRENCY_SYMBOL = ALL_CURRENCY [SITE_CURRENCY] [1]

ABSOLUTE_URL_OVERRIDES = {
    'auth.user': lambda o: "/user/detail/%s" % o.username,
}

DICT_FILE = '/usr/share/dict/words'

FIXTURE_DIRS = [ 'fixtures' ]
