#
#  File:       views.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Mon Aug 16 12:31:37 2010
#  Time-stamp: <2010-08-23 19:44:39 raskolnikov>
#

"""
  Auction API views.
"""

from django.core.urlresolvers import reverse
from django.shortcuts import get_object_or_404
from auction.models import Auction, do_bid
from auction.views import get_search_query_set
from django import http
from core.serialize import to_data_object
from core import rest
from functools import partial
from decimal import Decimal
from datetime import datetime

def data_from_auction_simple (fmt, auction):
    return to_data_object ('auction', {
        'name'        : auction.name,
        'location'    : reverse ('rest_auction_instance',
                                 kwargs = { 'fmt'     : fmt,
                                            'inst_id' : auction.pk }),
        'owner'       : auction.owner.username,
        'minimum-bid' : str (auction.minimum_bid),
        'created-on'  : str (auction.created_on),
        'finishes-on' : str (auction.finishes_on),
        'picture'     : auction.picture.url if auction.picture else str (None),
        })

def data_from_auction_detailed (auction):
    return to_data_object ('auction', {
        'name'        : auction.name,
        'description' : auction.description,
        'minimum-bid' : str (auction.minimum_bid),
        'created-by'  : auction.owner.username,
        'created-on'  : str (auction.created_on),
        'finishes-on' : str (auction.finishes_on),
        'picture'     : auction.picture.url,
        'highest-bid' : (data_from_bid (auction.highest_bid)
                         if auction.highest_bid and auction.highest_bid.who
                         else str (None)),
        'description' : auction.description,
        })

def data_from_bid (bid):
    return to_data_object ('bid', {
        'ammount'     : str (bid.ammount),
        'who'         : bid.who.username,
        'time-stamp'  : str (bid.time_stamp) })


class AuctionRest (rest.RestResource):

    resource = 'auction'

    def view_container_get (self):
        query, total = get_search_query_set (self.request)
        rest.check_last_modified (self.request, query)
        res = http.HttpResponse (self.serialize (
            { 'total'   : total,
              'results' : map (partial (data_from_auction_simple, self.fmt),
                               query) },
            root_tag = 'auction-search'))
        res ['Last-Modified'] = rest.formatdate (datetime.now ())
        return res
        
    def view_instance_get (self):
        request = self.request
        can_ban = request.user and request.user.has_perm ('can_ban_auction')
        query = Auction.objects.filter (pk = self.inst_id) if can_ban else \
                Auction.objects.filter (pk = self.inst_id, banned = False)
        rest.check_last_modified (self.request, query)
        return http.HttpResponse (self.serialize (
            data_from_auction_detailed (get_object_or_404 (
                query, pk = self.inst_id)),
            root_tag = 'auction-detail'))

    @rest.resource_require_authenticate
    def view_instance_bid_post (self):
        try:
            data = self.deserialize (self.request.raw_post_data)
            do_bid (self.inst_id, Decimal (str (data ['ammount'])),
                    self.request.user)
            return http.HttpResponse ()
        except Exception, e:
            raise rest.RestException (response = str (e))
