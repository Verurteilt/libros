#
#  File:       locking.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Sat Aug 14 17:42:52 2010
#  Time-stamp: <2010-08-14 20:42:05 raskolnikov>
#

"""
  Serializing concurrent access to models.
"""

from functools import partial
from django.db import connection, database


class lock:
    READ, WRITE = range (2)


class ModelLockBase (object):

    def __init__ (self, model = None):
        self.model = model

    def __enter__ (self):
        pass
    
    def __exit__ (self, *a):
        pass


class MysqlModelLock (object):
    
    def __init__ (self, lock_type = 'WRITE', *a, **k):
        super (MysqlModelLock, self).__init__ (*a, **k)
        self._mysql_lock_type = lock_type

    def __enter__ (self):
        cursor = connection.cursor ()
        table = self.model._meta.db_table
        cursor.execute ("LOCK TABLES %s %s" % (table, self.lock_type))

    def __exit__ (self, *a):
        """ Unlock the table. """
        cursor = connection.cursor ()
        cursor.execute ("UNLOCK TABLES")


class PostgresqlModelLock (object):
    
    def __init__ (self, lock_type = 'EXCLUSIVE', *a, **k):
        super (MysqlModelLock, self).__init__ (*a, **k)
        self._mysql_lock_type = lock_type

    def __enter__ (self):
        cursor = connection.cursor ()
        table = self.model._meta.db_table
        cursor.execute ("LOCK TABLE %s IN %s MODE" % (table, self.lock_type))


def lock_model (model, lock_type = lock.WRITE):
    return LOCK_FACTORIES [database ['ENGINE']] [lock_type] (model)


def require_lock_model (model, lock_type = lock.WRITE):
    def decorator (view):
        def wrapper (*a, **k):
            with lock_model (model, lock_type):
                return view (*a, **k)
        return wrapper
    return decorator


LOCK_FACTORIES = {
    'django.db.backends.sqlite3' :
    (ModelLockBase, ModelLockBase),
    'django.db.backends.mysql' :
    (partial (MysqlModelLock, lock_type = 'READ'),
     partial (MysqlModelLock, lock_type = 'WRITE')),
    'django.db.backends.postgresql' :
    (partial (PostgresqlModelLock, lock_type = 'SHARED'),
     partial (PostgresqlModelLock, lock_type = 'EXCLUSIVE'))
    }
