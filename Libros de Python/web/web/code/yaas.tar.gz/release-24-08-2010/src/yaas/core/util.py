#
#  File:       util.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Tue Jun 22 17:02:35 2010
#  Time-stamp: <2010-08-20 13:42:53 raskolnikov>
#

"""
  Generic abstractions and basic language extensions.
"""

def memoize (func):
    memory = {}
    def wrapper (*a):
        try:
            ret = memory [a]
        except KeyError:
            ret = memory [a] = func (*a)
        return ret
    return wrapper

@memoize
def mixin (one, two, *rest):
    class Mixin (one, two):
        def __init__ (self, *args, **kws):
            super (Mixin, self).__init__ (*args, **kws)

    if rest:
        return mixin (Mixin, *rest)
    return Mixin

def is_set (iterable):
    return len (set (iterable)) == len (iterable)

def find_if (alist, cond):
    index = 0
    while index < len (alist) and not cond (alist [index]):
        index += 1
    return index

def count_if (alist, cond):
    return len (filter (cond, alist))

def take_until (alist, cond):
    return alist [: find_if (alist, cond) ]

def drop_until (alist, cond):
    return alist [ find_if (alist, cond) : ]

class lazy (object):

    def __init__ (self, func):
        self._func    = func
        self.__name__ = func.__name__
        self.__doc__  = func.__doc__

    def __get__ (self, obj, cls = None):
        if obj is None:
            return None
        result = obj.__dict__ [self.__name__] = self._func (obj)
        return result

def get_as (dictionary, cls, key, default = None):
    try:
        res = cls (dictionary [key])
    except (ValueError, KeyError):
        res = default
    return res

def union (d1, d2):
    return union_in (dict (d1), d2)

def union_in (d1, d2):
    d1.update (d2)
    return d1

def translate_keys (dictionary, keymap):
    return dict ((keymap.get (k, k), v) for k, v in dictionary.iteritems ())

def rename_keys (func, **k):
    return lambda *a, **kk: func (*a, ** translate_keys (kk, k))

def fst (x): x [0]
def snd (x): x [1]

def ord_to_key (func, *a):
    return lambda *aa, **kk: \
           func (** union_in (kk, dict (filter (fst, zip (a, aa)))))

def identity (x, *a, **k):
    return x

