#
#  File:       resolve_auctions_server.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Mon Aug 16 10:42:19 2010
#  Time-stamp: <2010-08-16 18:45:19 raskolnikov>
#

"""
  Resolve all the auctions in a loop.
"""

from django.core.management.base import BaseCommand
from django.core.mail import send_mail
from resolve_auctions import resolve_all_auctions
import time
from optparse import make_option

class Command (BaseCommand):

    help = 'Run a server that performs resolve_auction periodically'    
    option_list = BaseCommand.option_list + (
        make_option ('-d', '--delay',
            type    = int,
            dest    = 'delay',
            default = 360,
            help    = 'Delay between executions.'),
        )

    
    def handle (self, *args, **options):
        while (True):
            resolve_all_auctions ()
            time.sleep (options ['delay'])
