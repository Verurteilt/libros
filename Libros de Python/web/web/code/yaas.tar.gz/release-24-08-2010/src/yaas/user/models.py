#
#  File:       models.py
#  Author:     Juan Pedro Bolivar Puente <raskolnikov@es.gnu.org>
#  Date:       Wed Jun 23 16:32:54 2010
#  Time-stamp: <2010-08-20 20:17:53 raskolnikov>
#

"""
  Models for user management.
"""

from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _
from os import path

def auction_picture_file (instance, filename):
    return path.join ('user_pics', str (instance.pk or 'new'))

default_picture = 'no-picture.png'

class UserProfile (models.Model):
    
    user           = models.OneToOneField (User, editable = False)
    
    telephone      = models.CharField (max_length = 16,
                                       blank = True,
                                       verbose_name = _("Telephone number"))
    address        = models.TextField (max_length = 1024,
                                       blank = True,
                                       verbose_name = _("Phisical address"))
    description    = models.TextField (max_length = 2048,
                                       blank = True,
                                       verbose_name = _("Personal description"))
    picture        = models.ImageField (upload_to = auction_picture_file,
                                        default   = default_picture,
                                        blank = True)

    # The activation related fields can be blank for users created in
    # the admin interface.
    activation_key = models.CharField (max_length = 40, editable = False,
                                       blank = True, null = True)
    key_expires    = models.DateTimeField (editable = False,
                                           blank = True, null = True)


User.profile = property (lambda u:
                         UserProfile.objects.get_or_create (user = u) [0])
