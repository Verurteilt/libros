"""

TEMA 4. FUNCIONES AVANZADAS
===========================

Iteradores
----------

  - Los iteradores sirven para recorrer listas de
    elementos. Un iterador 'apunta' a un elemento
    de una colección.

  - Se avanza con next ().
    1. Avanza el puntero al siguiente elemento.
    2. Devuelve el elemento actual.

  - Cuando no quedan elementos lanza StopIteration.

  - El metodo __iter__ devuelve a si mismo.

  - Pueden usarse en cualquier:
      for x in mi_iterador:
          ...

"""

it = iter (range (10))
try:
    while True:
        print it.next ()
except StopIteration:
    print "Fin!"

class IteradorVacio (object):
    def __iter__ (self):
        return self
    def next (self):
        raise StopIteration

for x in IteradorVacio ():
    print "No me ejecuto!"

"""

Generadores
-----------

  - Iteradores que no almacenan sus elementos en
    memoria - i.e. pueden ser infinitos.

  - Ejemplo típico: xrange vs range
            
  - En general son mas EFICIENTES!
       % timeit -n100 reduce (operator.add, range (10000))
       Aprox 10% mas eficiente.
       
"""

print "xrange:"
print xrange (5).__class__
for x in xrange (5): print x

print "range: "
print range (5).__class__
for x in range (5): print x

"""

- La biblioteca itertools tiene funciones como las
  de listas pero para iteradores/generadores y
  muchas mas.

- Pueden usarse sobre listas o cualquier otra
  colección o iterador.

"""

from itertools import *

it = chain ('Hola ', 'Mundo!')
print list (it)

it = chain ('Hola ', 'Mundo!')
it = ifilter (str.isupper, it)
print list (it)

a, b = tee (xrange (5), 2)
print list (a), list (b)

it = cycle ([1, 2])
it = islice (it, 10)
print list (it)

"""

- Python >= 2.5: yield

- Construye un iterador a partir de una función.

- El comando 'yield' sale de la función pero
  guarda el estado hasta la próxima iteración.
  
"""

def factoriales ():
    x = 1
    n = 2
    while True:
        yield x
        x *= n
        n += 1
        
it = factoriales ()
print it.__class__
print it.next ()
print it.next ()


"""

  - Listas infinitas!

  - Podemos jugar mas con el estado...

  - Numeros primos:
    * Almacenar los primos encontrados.
    * Comprobamos que el numero actual no es
      multiplo de los anteriores.
  
"""


"""

  - Cada vez que se crea un iterador se calculan
    los primos otra vez.

  - Vamos a hacer un decorador para generadores
    memoizantes...

"""


"""

  - Puede consumir mucha memoria!

  - En la práctica: usar itertools.tee !!!

"""

p1, p2 = tee (sieve ())

"""

  - El 'for generador':
        (for ... in ... [ if ... ])

  - Los paréntesis no son opcionales!

  - Como listas por comprehension pero generador
    por comprehension. MAS EFICIENTE!
  
"""

sum ([x*x for x in range(10)])
sum (x*x for x in range(10))

max (len(line) for line in file if line.strip())
dotprod = sum (x*y for x,y in izip (xv, yv))


"""

Decoradores
-----------

  - Sirven para annadir funcionalidad a una
    funcion, despues de definirla.

  - Sintaxis tradicional:

      def funcion (...):
          ...
      funcion = decorador (funcion)

  - Sintaxis nueva:

      @decorador
      def funcion (...):
          ...

  - El decorador devuelve otra funcion que
    envuelve a la anterior.

  - Hemos visto uno: gen_memoizer...
  
"""

def trace (fun):
    def wrapper (*a, **k):
        print "**>>:", fun.__name__, a, k
        res = fun (*a, **k)
        print "**<<:", fun.__name__
        return res
    return wrapper

@trace
def mi_funcion ():
    print "Ejecutando mi_funcion."

mi_funcion ()

"""

PROBLEMA:

  - Se pierden los metadatos de la funcion:
    a) __doc__
    b) __name__
    c) Signatura ...

SOLUCION:

  - functools.update_wrapper, functools.wraps

"""

help (mi_funcion)

from functools import wraps

def trace (fun):
    @wraps (fun)
    def wrapper (*a, **k):
        print "**>>", fun.__name__, a, k
        res = fun (*a, **k)
        print "**<<", fun.__name__
        return res
    return wrapper

@trace
def mi_funcion ():
    print "Ejecutando mi_funcion."

help (mi_funcion)

"""

  - Detras de la arroba en realidad podemos poner
    cualquier expresion.

  - Podemos generar el decorador con una funcion.

  - Por tanto podemos parametrizar el decorador.

"""

import sys
def trace (out = sys.stdout):
    def decorator (fun):
        @wraps (fun)
        def wrapper (*a, **k):
            print >> out, "**>>", fun.__name__, a, k
            res = fun (*a, **k)
            print >> out, "**<<", fun.__name__
            return res
        return wrapper
    return decorator

@trace ()
def mi_funcion ():
    print "Ejecutando mi_funcion"

mi_funcion ()

@trace (sys.stderr)
def mi_funcion ():
    print "Ejecutando mi_funcion"

mi_funcion ()

"""

  - Las clases tambien pueden decorarse desde 2.6.

  - Esto es mas nuevo, avanzado y peligroso, no
    vamos a ahondar en ello (a veces es mejor usar
    una metaclase).

  - Ejemplo util: functools.total_ordering.

  Decoradores comunes
  -------------------

  - property: Puede usarse cuando tenemos una
    propiedad de solo lectura.

  - staticmethod: Metodo de una clase no recibe ni
    la clase ni el objeto como
    parametro. Normalmente es mejor usar una
    funcion libre, pero puede ser util cuando
    queremos polimorfismo.

  - classmethod: Metodo que pertenece a la clase,
    no la instancia. El parametro implicito sera
    la clase del objeto.
    
"""

class Clasecilla (object):

    @property
    def propiedad (self):
        print "Propiedad"
    
    @staticmethod
    def estatico ():
        print "Metodo estatico"

    @classmethod
    def declase (cls):
        print "Metodo de clase: ", cls

Clasecilla.estatico ()
Clasecilla.declase ()

obj = Clasecilla ()
obj.propiedad
obj.estatico ()
obj.declase ()


"""

Control de recursos
-------------------

  - Patron recurrente:
      1. tomar-recurso
      2. usar-recuro
      3. liberar-recurso

  - Ejemplo:
      * C:   malloc ()  -->  free ()
      * C++: new        -->  delete

  - Creencia erronea:
      'Solo afecta a la memoria.'

  - Recursos con abrir/cerrar:
      * ficheros
      * bases de datos
      * conexiones de red (sockets)
      * mutexes
      * ...

Primera aproximacion
--------------------

  - __init__   --> __del__

  - __del__ se invoca cuando el recolector de
    memoria va a liberar le objeto. 

  - 'cpython' usa conteo de referencias por lo
    que esto sirve en muchos casos si se
    evitan ciclos.

  - 'jython' o 'ironpython' usan recolector de
    basura siempre, debemos escribir codigo PORTABLE
      
"""

"""

¿Conteo de referencias?

  - Cada vez que se a signa un objeto a una
    variable se incrementa la cuenta.

  - Cuando una variable desaparece o reasigna se
    decrementa la cuenta.

  - Cuando la cuenta llega a 0 se libera la
    memoria.

  - PROBLEMA: Las referencias circulares hacen que
    nunca se librere el objeto!

  - SOLUCION 1: Se usa un recolector de basura que
    busca todos los objetos accesibles de la pila.

  - SOLUCION 2: Aun asi viene bien evitar las
    referencias circulares. Usar para ello:

        ref = weakref.proxy (objeto)
        ref = weakref.ref (objeto)
"""

class Foo (object): pass
import weakref
root = Foo ()
child1 = weakref.proxy (root)
child2 = weakref.ref (root)
child1.attr = child1
print child2 ().attr
del root
print child2 ()
try:
    print child1.attr
except ReferenceError, err:
    print err

"""

Segunda aproximacion
--------------------

    * Simplemente podemos abrir/cerrar
      manualmente.

    * ¿Pero que pasa con las excepciones?

"""

def copyfile (infile, outfile):
    writer = open (outfile, 'w')
    reader = open (infile)
    writer.write (reader.read ())
    reader.close ()
    writer.close ()

copyfile ('test-in', 'test-out')

"""

PROBLEMA:

  - Si la linea:
        reader = open (infile)

    Tira una excepcion, el primer fichero se queda
    abierto.

  - Solucion:

    try:
       ...
    except ...:
       ...
    finally:
       ...

    En el bloque 'finally' podemos liberar los
    recursos. Se ejecuta siempre al salir del
    bloque, se hayan tirado o no excepciones, y se
    hayan capturado o no. 
"""

def copyfile (infile, outfile):
    writer = open (outfile, 'w')
    try:
        reader = open (infile)
        writer.write (reader.read ())
        reader.close ()
    finally:
        writer.close ()
    
copyfile ('test-in', 'test-out')

"""

Normalmente el codigo se vuelve barroco. Esto nos
lleva al patron RAII -- Resource Adquisition Is
Initialization.

Tercera solucion
----------------

  - RAII: Definir una nocion de 'recurso' asociada
    a un bloque sintactico. (Python 2.5)

  - Inspirado en C++ y Lisp (with-open-file) 

  - Definimos el recurso que queremos usar con
    'with' y este se libera automaticamente al
    salir del bloque sea mediante una excepcion o
    al finalizar correctamente.
    
  - Sintaxis:

    with adquirir_recurso () as recurso:
        ...

  - Python >= 2.7:
    with A() as a, B() as b: ...
    
"""

def copyfile (infile, outfile):
    with open (outfile, 'w') as writer:
        with open (infile) as reader:
            writer.write (reader.read ())

copyfile ('test-in', 'test-out')

"""

  - Los recursos definidos se llaman 'Context
    managers' o 'Gestores de contexto'.

  - Son objetos que definen:
      * __enter__: Se ejecuta al entrar el with.
      * __leave__: Se ejecuta al salir del with.

  - Es mas facil definirlos con contextlib.contextmanager.

"""

from contextlib import contextmanager

@contextmanager
def tag (name):
    print "<%s>" % name
    yield
    print "</%s>" % name

with tag ('body'):
    print "Un parrafo!"

