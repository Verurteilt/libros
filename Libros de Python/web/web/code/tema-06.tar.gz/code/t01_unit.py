"""

PRUEBAS DE UNIDAD
=================

Conceptos
---------

  - test fixture:

    Preparacion que necesita un test para
    realizarse (p.e. establecer una conexion de
    bases de datos de prueba).

  - test case:

    Es una prueba individual. Suele ser una
    funcion pequegna que prueba una propiedad del
    contrato o las propiedades de una funcion.

  - test suite:

    Una coleccion de pruebas que tienen algo en
    comun y se espera que se ejecuten todos en
    conjunto. (p.e. las pruebas de una clase o las
    de una funcion)

  - test runner:

    Es el componente que se encarga de ejecutar
    todas las pruebas de unidad de un sistema.

En Python:

  1. Una prueba de unidad hereda de
     unittest.TestCase.

  2. Definimos metodos test* que ejecuten el
     codigo de las pruebas de unidad.

     Al hacer las pruebas de unidad podemos usar
     los metodos:

       self.assert[Equal, Raises, True, ...]
       self.failUnless [...]

  3. El estado del la clase puede usarse. Para
     establecere el 'fixture' definimos:

       setUp (self):
         Se ejecuta antes de cada test.

       teardown (self):
         Se ejecuta despues de cada test.

  4. Ejecutar.

       unitest.main ()
       
"""

import random
import unittest

class TestSequence (unittest.TestCase):

    def setUp (self):
        self.seq = range (10)

    def test_shuffle (self):
        random.shuffle (self.seq)
        self.seq.sort ()
        self.assertEqual (self.seq, range (10))
        self.assertRaises (TypeError, random.shuffle, (1,2,3))

    def test_choice (self):
        element = random.choice (self.seq)
        self.assertTrue (element in self.seq)

    def test_sample (self):
        # En Python 2.7 podemos usar esto.
        # with self.assertRaises (ValueError):
        #    random.sample (self.seq, 20)
        self.assertRaises (ValueError, random.sample, self.seq, 20)
        for element in random.sample (self.seq, 5):
            self.assertTrue (element in self.seq)

"""

  - La herencia es util para compartir el fixture
    de la prueba.

"""

class BaseTestSequence (unittest.TestCase):
    def setUp (self):
        self.seq = range (10)
        
class TestSequenceShuffle (BaseTestSequence):
    def runTest (self):
        random.shuffle (self.seq)
        self.seq.sort ()
        self.assertEqual (self.seq, range (10))
        self.assertRaises (TypeError, random.shuffle, (1,2,3),
                           'Las listas inmutables no se cambian.')

class TestSequenceChoice (BaseTestSequence):
    def runTest (self):
        element = random.choice (self.seq)
        self.assertTrue (element in self.seq)

"""

if __name__ == '__main__':
    unittest.main ()

"""

"""

Otros metodos de TestCase:

  - TestCase.run ([result])

    Ejecuta la prueba y individual y guarda el
    resultado en result. Result es de tipo TestResult.
    
  - TestCase.debug ()

    Ejecuta la prueba ta cual. Esto sirve para que
    el sistema no capture las excepciones
    facilitando la depuracion.

Luego, podemos construir suites de tests.

  - Al instanciar un TestCase que no define
    runTest, le tenemos que pasar de parametro el
    metodo concreto a ejecutar.

  - Una TestSuite tambien tiene run () y debug ()
  
"""

def suite ():
    suite = unittest.TestSuite ()
    suite.addTest (TestSequence ('test_shuffle'))
    suite.addTest (TestSequenceChoice ())
    return suite

def suite ():
    tests = ['test_shuffle', 'test_choice']
    return unittest.TestSuite (map (TestSequence, tests))

suite = lambda: unittest.TestLoader ().loadTestsFromTestCase (TestSequence)

"""

  - En la mayoría de los casos no vamos a crear
    los suites a mano.

  - En su lugar usamos 'main'. El busca
    recursivamente en todos los modulos accesibles
    clases que heredan de 'TestCase' y agnade
    todos sus tests.

    * Tener cuidado al usar jerarquias.

    * Se puede customizar el comportamiento.


  - Metodologia:

     * Por cada modulo definir un modulo
       test_modulo con las pruebas.

     * Tener un script principal donde importamos
       estos modulos y llamamos al main de unittest.

  - En Python es especialmente importante las
    pruebas de unidad:

      * Al ser dinamico, no se sabe si el codigo
        es correcto hasta que se ejecuta.

      * Importante covertura ~100%.

    TODO: TEST COVERTURA.
    
"""
