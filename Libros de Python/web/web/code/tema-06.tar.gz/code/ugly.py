import string

shift = 3
choice = raw_input("Want to encode or decode?: ")
word = (raw_input("Enter the text: "))
letters = string.ascii_letters + \
          string.punctuation + \
          string.digits
nletter = len (letters)
encoded = ''
if choice == "encode":
    for letter in word:
        if letter == ' ':
            encoded = encoded + ' '
        else:
            x = letters.index(letter) + shift
            encoded=encoded + letters[x % nletter]
if choice == "decode":
    for letter in word:
        if letter == ' ':
            encoded = encoded + ' '
        else:
            x = letters.index(letter) - shift
            encoded = encoded + letters[x % nletter]

print encoded
