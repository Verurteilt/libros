"""

ANALISIS ESTATICO
=================

  - Aunque Python sea dinamico, podemos comprobar
    muchas cosas con analisis estatico.

    Ejemplos:

      ¿Se redefinen nombres globales?  ¿Se siguen
      las convenciones del PEP8?  ¿Hay indicios de
      mala programacion (i.e. clases que hacen
      todo en el constructor, etc.)?

    En general dan falsos positivos (cosas que
    deliberadamente hemos puesto) pero pueden
    usarse como guia y ayuda en la deteccion de
    errores.

  (Ver bad.py)
  
"""

"""

PyFlakes
--------

  - Es el mas ligero de todos.
  - No compila los modulos.
  - No comprueba el estilo.

  (Lo tengo integrado en Emacs)

  $ pyflakes .
  $ pyflakes fichero.py
  $ pyflakes fich1 fich2 dir1 dir2 ...

  Found warnings including unused importes,
  undefined variables and unnecessary reimports,
  are printed on standard output.  Found errors
  including compile or encoding errors, are
  printed on standard error.

"""

"""

PyLint
------

  - El nombre viene de Lint, una herramienta para
    C con mucha historia.

  - Comprueba un monton de cosas. Podemos activar
    y desactivar que comprueba con -e y
    -d. Tambien muestra estadisticas con opciones
    (como con -f colorize).

  - Soporta plugins.

"""

"""

  Viene con otros programas:

  - pyreverse: an UML diagram generator
  - symilar: an independent similarities checker
  - epylint: Emacs and Flymake compatible Pylint
  - pylint-gui: a graphical interface

"""


"""

  Parametros principales:

Master:
  --rcfile=<file>
Commands:
  --help-msg=<msg-id>
Message control:
  --disable=<msg-ids>
Reports:
  --files-output=<y_or_n>
  --reports=<y_or_n>
  --include-ids=<y_or_n>
  --output-format=<format>

Output:
   Using the default text output, the message format is :
  MESSAGE_TYPE: LINE_NUM:[OBJECT:] MESSAGE
  There are 5 kind of message types :
  * (C) convention, for programming standard violation
  * (R) refactor, for bad code smell
  * (W) warning, for python specific problems
  * (E) error, for much probably bugs in the code
  * (F) fatal, if an error occured which prevented pylint from doing
  further processing.
  
"""

"""

  Ejemplo: ugly.py

    * pylint --include-ids=y
    * pylint --help-msg=C0111
    * pylint --reports=n --include-ids=y --disable=W0402
    * pylint --reports=n --include-ids=y --disable=W0402 --const-rgx='[a-z_][a-z0-9_]{2,30}$'
    
"""

"""

  - Revisiones basicas.
  
    * Presencia de cadenas de documentación (docstring).
    * Nombres de módulos, clases, funciones, métodos,
      argumentos, variables.
    * Número de argumentos, variables locales, retornos y
      sentencias en funciones y métodos.
    * Atributos requeridos para módulos.
    * Valores por omisión no recomendados como argumentos.
    * Redefinición de funciones, métodos, clases.
    * Uso de declaraciones globales.

  - De variables.

    * Determina si una variable o import no está siendo usado.
    * Variables indefinidas.
    * Redefinición de variables proveniente de módulos builtins
      o de ámbito externo.
    * Uso de una variable antes de asignación de valor.

  - De clases.

    * Métodos sin self como primer argumento.
    * Acceso único a miembros existentes vía self
    * Atributos no definidos en el método __init__
    * Código inalcanzable.

    * Uso de property, __slots__, super.
    * Uso de super.


  - De disegno.

    * Número de métodos, atributos, variables locales, . . .
    * Tamaño, complejidad de funciones, métodos, . . .

  - De importaciones.

    * Dependencias externas.
    * imports relativos o importe de todos los métodos, variables
      vía * (wildcard).
    * Uso de imports cíclicos.
    * Uso de módulos obsoletos.

  - De formato.

    * Construcciones no autorizadas
    * Sangrado estricto del código
    * Longitud de la línea
    * Uso de <> en vez de !=

    * Notas de alerta en el código como FIXME, XXX.
    * Código fuente con caracteres non-ASCII sin tener una
      declaración de encoding. PEP-263
    * Búsqueda por similitudes o duplicación en el código
      fuente.
    * Revisión de excepciones.
    * Revisiones de tipo haciendo uso de inferencia de tipos.

"""

"""

  - PyLint es un poco... fascista.

  - Es una buena idea personalizar las
    comprobaciones a nuestro estilo de
    programacion.

  - Generar un fichero de configuracion con
    --generate-rcfile.

    pylint --reports=n --include-ids=y --additional-builtins=_ \
    --disable-msg=I0011 --generate-rcfile > .pylintrc

  - Podemos cargar un fichero diferente del por
    defecto ($HOME/.pylintrc) con: --rcfile=...

  - Tambien, podemos especificar opciones en el
    propio codigo para darle cuartel a secciones
    que creemos correctas:

    #pylint: disable-msg: W0232
    
"""

"""

PyChecker
---------

  - Otra herramienta estilo pylint. Tal vez menos
    mantenida y completa, pero mas facil de usar.

  - La probamos...

  - Las opciones de comprobacion se pueden poner
    en el propio codigo:

        __pychecker__

  __pychecker__ = 'no-namedargs maxreturns=0 unusednames=foo,bar'

  - Se puede invocar directamente desde el codigo.

       import pychecker.checker

    Todos los modulos importados despues de estos
    seran comprobados.

  - La variable de entorno PYCHECKER_DISABLED
    puede usarse (con el valor 1) para desactivar
    estas comprobaciones.
  
"""

"""

  - Pychecker y Pylint funcionan con paquetes y
    bibliotecas instalados. ¿Se quejan mutuamente?

"""
