"""

PRUEBAS
=======

Programacion por Contrato
-------------------------

  - Especificar un 'contrato' entre el programador
    de un modulo y el usuario de ese modulo.

  - Disegnado especialmente para la orientacion a
    objetos (Eiffel, Bertrand Meyer).

  - Un contrato incluye:

    * Precondiciones: Que deben satisfacerse antes
      de invocar un metodo.

    * Postcondiciones: Que deben satisfacerse
      despues de invocar un metodo (estado, etc.)

    * Invariantes: Propiedades del estado que no
      cambian antes y despues de ejecutar un
      metodo.

  - Ejemplo:

    clase Racional:

      Atributos:
       > num -- Numerador
       > den -- Denominador

      Invariantes:
       > num es Entero
       > den es Entero
       > den != 0

      Metodos:

       > __idiv__ (self, a):

         Precondiciones:
           - self es Racional
           - a es Racional
           - Si a.num es 0 entonces tira la
             excepcion DivisionByZero
           
         Postcondiciones:
           - self'.den = self.den * a.num
           - self'.num = self.num * a.den

Satisfaciendo el contrato
-------------------------

  - Algunas de las precondiciones son a mantener
    por el usuario, pero el desarrollador del
    modulo es la parte mas importante del
    contrato.

  - En Python, el programador puede comprobar que
    satisface su parte del contrato escribiendo
    pruebas de unidad.

  - Las pruebas de unidad son pequegnas funciones
    que comprueban que el codigo satisface el
    contrato. (Si no son pequegnas, puede ocurrir
    que los problemas esten en el codigo de pruebas!)

"""

"""

DOCTEST
-------

  - Permite incluir pruebas directamente en la
    documentacion embebida -- docstrings.

  - Es como el texto de una sesion interactiva en
    el interprete de Python. Python comprueba que
    esa sesion se ejecuta correctamente.

  - La funcion doctest.testmod ([m]) ejecuta las
    pruebas del modulo actual.

      * Todos los docstrings del modulo
        (funciones, clases, etc..).

      * Los docstrings de __test__

      * No se busca recursivamente en modulos
        importados.

  - La funcion doctest.testfile (nomfich) ejecuta
    las pruebas en un fichero de texto arbitrario.

Sintaxis:
---------

  - Ideado para hacer copy-paste de una sesion
    interactiva, pero no exactamente.

  - Las lineas de codigo empiezan por >>> y puede
    continuarse un bloque con ...:

    >>> x = 12
    >>> x
    12
    >>> if x == 13:
    ...     print "yes"
    ... else:
    ...     print "no"
    ...     print "NO"
    ...     print "NO!!!"
    ...
    no
    NO
    NO!!!

  - Podemos comprobar:
    a) El valor devuelto por la ultima expresion.
    b) El contenido de la salida estandar (no stderr).

  - La salida esperada no puede tener lineas
    vacias, se consideran EOF. Para poner lineas
    vacias usar <BLANKLINE>.

  - Si quremos usar contrabarras, hay que
    escaparlas o usar un 'docstring en bruto':

    >>> def f(x):
    ...     r'''Backslashes in a raw docstring: m\n'''
    >>> print f.__doc__
    Backslashes in a raw docstring: m\n

  - La linea de comienzo no importa:

    >>> assert "Easy!"
        >>> import math
            >>> math.floor(1.9)
            1.0

  - Pueden usarse excepciones:

    >>> [1, 2, 3].remove(42)
    Traceback (most recent call last):
      File "<stdin>", line 1, in ?
    ValueError: list.remove(x): x not in list

    El traceback normalmente no aporta valor --
    peor aun, revela detalles de implementacion,
    asi que podemos omitirlo:

    >>> [1, 2, 3].remove(42)
    Traceback (most recent call last):
      ...
    ValueError: list.remove(x): x not in list

  - Podemos usar directivas:

    >>> print range(20) # doctest: +ELLIPSIS, +NORMALIZE_WHITESPACE
    [0,    1, ...,   18,    19]

  - Estas directivas estan doctest
    (p.e. doctest.ELLIPSIS) y pueden ser
    compuestas con | estilo 'banderas' y pasarselas a las funciones de test:

    doctest.testmod (optionflags = doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

"""
if __name__ == "__main__":
    import doctest
    doctest.testmod ()






