"""

BIBLIOTECAS EXTERNAS
====================

"""

from ctypes import *
from ctypes import util

_cstd = cdll [util.find_library('c')]
_cmath = cdll [util.find_library('m')]

"""

Bibliotecas
-----------

"""

"""

Tipos
-----

"""

"""

Punteros

"""

i = c_int ()
_cstd.sscanf ("123", "%i", byref (i))
print i

"""

Vectores

"""

int3 = c_int * 3

a3 = int3 ()
print list (a3)

a3 = int3 (* range (3))
print list (a3)

def io_errcheck (res, func, args):
    if not res:
        raise IOError, 'Error opening file'
    return res
_cstd.fopen.errcheck = io_errcheck
try:
    _cstd.fopen ('notexist', 'r')
except IOError, err:
    print err
    
"""

Estructuras
-----------

"""

class c_tm (Structure):
    _fields_ = (
        ('tm_sec', c_int),  ('tm_min',  c_int),
        ('tm_hour', c_int), ('tm_day', c_int),
        ('tm_mon',  c_int), ('tm_year', c_int),
        ('tm_wday', c_int), ('tm_yday', c_int),
        ('tm_isdst', c_int))

_cstd.localtime.restype = POINTER (c_tm)

t = c_int (_cstd.time (0))
lt = _cstd.localtime (byref (t)).contents
print "%d/%02d/%02d" % (lt.tm_year + 1900, lt.tm_mon, lt.tm_day)

"""

Funciones
---------

"""

cmpfunc = CFUNCTYPE (c_int, POINTER (c_int), POINTER (c_int))

@cmpfunc
def mycmp (a, b):
    return cmp (a[0], b[0])

arr = (c_int * 10) (* reversed (xrange (10)))
print list (arr)
_cstd.qsort (arr, 10, sizeof (c_int), mycmp)
print list (arr)


from numpy.ctypeslib import ndpointer
from numpy import array

_funcs = CDLL ('./funcs.so')

vec3 = ndpointer (dtype = 'float32',
                  ndim  = 1,
                  shape = (3,),
                  flags = 'C_CONTIGUOUS')
_funcs.dotprod3.argtypes = vec3, vec3
_funcs.dotprod3.restype  = c_float

print _funcs.dotprod3 (
    array ([1., 1., 1.], dtype = 'float32'),
    array ([0., 0., 3.], dtype = 'float32'))

