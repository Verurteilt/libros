
"""

2. PROGRAMACION FUNCIONAL
=========================

Repaso...

"""

def funcion (param, clave = "default"):
    print "Ejecutando funcion (" + \
          str (param) + ", clave = " \
          + str (clave) + ")"
    return None

funcion (1)
funcion (1, "personal")

"""

Funciones variadicas
--------------------

- Operadores * y **:

  * En la lista de parámetros:

    > *: Captura los parametros variables que se
         pasen a la funcion en una tupla.
          
    > **: Captura los parametros 'por clave' que
          se pasen a la función en un diccionario:
          
  * En una llamada a función:

    > *: Expande una secuencia (tupla, lista...)
         como parámetros de una funcion.
          
    > **: Expande un diccionario como parametros
          por clave.

- Poner las claves al final!

"""

def funcion (*args, **keys):
    print "-- Llamando a funcion con: -- "
    print "Parametros: ", args
    print "Claves:     ", keys

funcion (1, 2, 3, 'manolete')
funcion (nombre    = 'Juan Pedro',
         apellidos = 'Bolivar Puente')

def sum3 (a, b, c):
    return a + b + c

print sum3 (* range (3))

def persona (nombre = 'Anonimo',
             apellidos = 'Bastardo',
             dni = 'Sin DNI'):
    print apellidos + ",", nombre, "(" + dni + ")"
    
yo = { 'nombre'    : 'Jhon',
       'apellidos' : 'Doe' }
persona (**yo)

"""

Programación funcional
----------------------

- Programación imperativa -> estructurada -> OO:
  Modelo: Maquina de Turing

- Programación funcional:
  Modelo: Lambda Calculi

Imperativo:
  - Ir asignando valores a variables.
  - La memoria tiene un estado global que va cambiando.
  - El programa se compone de *sentencias*
  
"""

import random
y = random.randint (0, 10)
x = 1
if y % 2:
  x = x + 3
else:
  x = x - 2
print x

"""

Funcional (declarativo):
  - Idealmente las variables son inmutables.
  - Funciones de primer orden.
  - Mas 'matematico'.
  - Lo importante son las expresiones.

"""

y = random.randint (0, 10)
x = 1 + (3 if y % 2 else -2)
print x

"""

- Acabamos de ver el 'expression if'
- El codigo tiende a ser mas... compacto u horizontal.
- A veces mas dificil.

- Pero necesitamos que las funcione sean 'valores
  de primer orden', formalmente:

  (Concepts, Techniques and Models of Computer
  Programming, Peter Van Roy and Seif Haridi)
  
1. 'Genericidad':
   - Funciones pueden pasarse como parametro.
     (Funciones de alto orden).

"""

def ejecutarfun1 (funcion):
    resultado = funcion ()
    print "Resultado: " + str (resultado)
ejecutarfun1 (random.random)

"""

2. 'Instanciacion'
   - Las funciones pueden devolver otras funciones.

"""

def devuelvefun1 (param):
    if param:
        return random.random
    else:
        return list

fun = devuelvefun1 (True)
print fun ()
fun = devuelvefun1 (False)
print fun ()

def devuelvefun1_alter (param):
    return random.random if param else list

"""

3. 'Abstraccion procedural'
   - Cualquier sentencia puede convertirse en un procedimiento
   - Definir funciones en cualquier parte, que usen los valores de su
     entorno.

"""

def make_sumador (k):
    def sumador (x):
        return x + k
    return sumador

mas_dos = make_sumador (2)
print mas_dos (1)
print mas_dos (2)

"""

  - Esto es utilisimo, por eso podemos usar:
        lambda parametros: expresion

  - Para definir una funcion anonima (sin nombre
       asociado a priori).

"""

def make_sumador_lambda (k):
    return lambda x: x + k

mas_dos = make_sumador_lambda (2)
print mas_dos (1)
print mas_dos (2)

"""

  - ¡Cuidado con la captura!
  - Se hace por valor, no por nombre.

"""

try:
    def make_contador (x):
        def contador ():
            x += 1
        return contador

    var = 2
    cnt = make_contador (var)
    cnt (); cnt ()
    print var # 2!!
except NameError, err:
    print err

def make_contador (x):
    def contador ():
        x [0] += 1
    return contador

var = [2]
cnt = make_contador (var)
cnt (); cnt ()
print var

"""

4. 'Embebimiento'
   - Las funciones son valores.
   - Pueden almacenarse en estructuras de datos.
   
"""

from operator import add, sub, div #, mul
funcs = {
    '+'  : add, 
    '-'  : sub,
    '*'  : lambda a, b: a * b,
    '/'  : div
    }
print funcs ['+'] (1, 2)
print funcs ['-'] (1, 2)
print funcs ['*'] (1, 2)
print funcs ['/'] (1, 2)

"""

Funciones de alto orden:
- Tienen funciones como parametro.
- Abstraen 'iteracion' sobre secuencias.
- Funciones mas comunes:
  * map (funcion, lista)
  * reduce (funcion, lista [, valor inicial])
  * filter (funcion, lista)

"""

print map (lambda x: x * 2, range (10))
print reduce (lambda x, y: x + y, range (10))
print filter (lambda x: x % 2 == 0, range (10))

"""

Currificacion:
- Fijar algunos parametros.
- functools

"""

from functools import partial
from operator import mul, add

print map (partial (mul, 2), range (10))
print reduce (add, range (10))

def compose (*funcs):
    def compuesta (x):
        for f in reversed (funcs):
            x = f (x)
        return x
    return compuesta

def compose (*funcs):
    return lambda x: reduce (lambda x, f: f (x), funcs[::-1], x)

print compose (partial (mul, 3), partial (add, 2)) (1)

"""

Nota: No siempre conviene usar map y filter.

- En cuanto la expresion lambda es compleja o hay que combinar map y
filter es mejor usar 'comprehensiones de listas'.

"""

res = [ x * 2 for x in range (10) if x % 2 == 0 ]
print res

res = map (lambda x: x * 2, filter (lambda x: x % 2 == 0, range (10)))
print res

print range (0, 20, 4)


"""

Utilidades importantes
----------------------

"""

print zip ('hola', range (3))
print all ([True, [], True])
print any ([True, [], True])
print list (reversed (range (4)))
