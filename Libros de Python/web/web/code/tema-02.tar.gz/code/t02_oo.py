"""

TEMA 3. ORIENTACION A OBJETOS
=============================

Objetos
-------

  - Objeto:
    Estado (atributos) + Funciones.

  - Como en Python las funciones son como
    cualquier otro valor:
        Objeto = diccionario.

  - Se accede a los miembros con el 'operador punto'
        objeto.miembro
        
  - Todos los valores en Python son objetos:
    a) Tipos simples.
    b) Clases y tipos.
    c) Funciones.
    d) Modulos.
    
"""

print (123).__class__
print zip.__class__
print list.__class__
import os
print os.__class__

"""

Clases
------

  - Todo objeto tiene una clase, incluidas las clases
    en si (metaclases).

  - En 2.2 modificaron el sistema de clases.
    Las nuevas clases heredan de Object.

Sintaxis:

  class Clase (Base1, Base2, ...):
      <sentencia1>
      <sentencia2>
      ...

Definen:
    a) Funciones
    b) Atributos por defecto
    c) Cualquier sentencia de Python en verdad,
       instalando los 'nombres' en la clase.

Constructores:

  - Una clase es una funcion, al ejecutarla nos da
    un objeto.

  - El constructor se cambia con __init__.

"""

class Foo (object):
    un_atributo = 3

    def __init__ (self, otro = None):
        self.otro_atributo = otro
        
    def metodo (self):
        print "Metodo de: ", self

obj = Foo ()
print obj
print obj.un_atributo
print obj.otro_atributo

obj = Foo (10)
print obj.otro_atributo

obj.un_atributo = 15
print obj.un_atributo
print Foo.un_atributo
obj.metodo ()

"""

Atributos
---------

Como en cualquier diccionario podemos anadir y
quitar elementos en cualquier momento.

"""

obj.nuevo_atributo = 2
print obj.nuevo_atributo

del obj.nuevo_atributo
print hasattr (obj, 'nuevo_atributo')

obj.metodo = 3
print obj.metodo

"""

- El operador punto, con una funcion, devuelve una
  nueva funcion con el primer parametro fijado.
  
- Util para optimizar.

"""

from functools import partial

fn = obj.metodo
fn ()

fn = partial (Foo.metodo, obj)
fn ()

"""

Podemos acceder con una cadena (getattr, setattr):

- Para saltarnos las reglas de identificadores.
- Para elegir una funcion o miembro,
  DINAMICAMENTE!

"""

class Bar (object):
    def func_one (self):
        print "Primera funcion."
    def func_two (self):
        print "Segunda funcion."

obj = Bar ()

import random

cadena = random.choice (['one', 'two'])
getattr (obj, 'func_' + cadena ) ()

setattr (obj, 'una cosa!', 123)
print getattr (obj, 'una cosa!')

"""

Encapsulacion
-------------

- Ocultar los datos 

- Idea:
  * Una funcion expone un nombre, pero puede
    cambiar por dentro.
  * Por tanto, los datos deben ser inaccesibles.
  * Datos privados:
     > (private, public de C++, Java ...)
     > En Python no existen, por convencion _atributo.

- Python tiene propiedades.

"""

class BadExample (object):
    _data = None
    def set_data (self, data):
        self._data = data
    def get_data (self):
        return self._data

"""

*Python no es Java!*

- Cuando un dato es parte de la interfaz...
  Lo hacemos publico directamente!

- Cuando cambia usamos property.

"""

class GoodExample (object):
    data = None

obj = GoodExample ()
obj.data = 3
print obj.data

class GoodExample (object):
    _data = None

    def _set_data (self, value):
        print "Setting data"
        self._data = value

    def _get_data (self):
        print "Getting data"
        return self._data
    
    data = property (_get_data, _set_data)

obj = GoodExample ()
obj.data = 3
print obj.data

class GoodExample (object):
    _data = None

    def data ():
        doc = """ Doc """
        def fset (self, value):
            print "Setting data"
            self._data = value
        def fget (self):
            print "Getting data"
            return self._data
        return locals ()
    data = property (** data())

obj = GoodExample ()
obj.data = 3
print obj.data


"""

Herencia
--------

- Una clase puede heredar de otra y tomar sus
  funciones y propiedades, sobrecargando
  (redefiniendo) lo que necesite y annadiendo sus
  propios metodos.

- Terminologia:
  clase base  -> clase derivada
  super-clase -> sub-clase
  
"""

class Base (object):
    def method (self):
        print "base.method ()"
    def other (self):
        print "base.other ()"

class Deriv (Base):
    def method (self):
        print "deriv.method ()"

def invoca_metodo (obj):
    obj.metodo ()

ob = Base ()
ob.method ()
ob.other ()
invoca_metodo (obj)

od = Deriv ()
od.method ()
od.other ()
invoca_metodo (obj)

class Otra (object):
    def method (self):
        print "otra.method"

"""

Llamar metodos de la clase base:

  - Algunos recomiendan:
      Base.method (self) -> MAL!

  - Mejor usar:
      super (Clase, objeto).method ()

  - Importante, por ejemplo, en __init__.

  (Hablaremos mas de esto.)

"""

super (Deriv, od).method ()

"""

Usos herencia principales:

  - Extension.
    Anadir funcionalidad a un tipo ya definido.
    
  - Especializacion.
    Definir un comportamiento mas concreto
    sobrecargando metodos de la clase base.

    (Object Oriented Programming, Timothy Budd)
    
Interfaces:

  - En Python no son tan utiles - duck typing.

  - Sirven para *obligar* a sobrecargar ciertos
    metodos tirando NotImplemented.

"""

class Graphic (object):
    def __init__ (self, x, y):
        self.x = x
        self.y = y
    
    def draw (self):
        raise NotImplemented

    def _set_pos (self, (x, y)):
        self.x = x; self.y = y
    pos = property (lambda self: (self.x, self.y),
                    _set_pos)

class Square (Graphic):
    def __init__ (self, x, y, size):
        super (Square, self).__init__ (x, y)
        self.size = size
        
    def draw (self):
        print " Square (" + repr (self.size) + ") en " + \
              repr (self.pos)

class Triangle (Graphic):
    def __init__ (self, x, y, base, height):
        super (Triangle, self).__init__ (x, y)
        self.base = base
        self.height = height

    def draw (self):
        print " Triangle " + repr ((self.base, self.height)) + \
              " en " + repr (self.pos)

def draw_all_graphics (graphs):
    for x in graphs:
        x.draw ()

glist = [ Triangle (0, 0, 1, 2),
          Square (1, 1, 2) ]

draw_all_graphics (glist)

"""

Herencia multiple
-----------------

  - Muchos lenguajes lo prohiben.

  - Python mola y la tiene!

  - Problema del Diamante (ver transparencias.)
    Que metodo llamar?
    Orden C3!

    http://www.python.org/download/releases/2.3/mro/
    
"""

class A (object):
    def method (self):
        print "A.method"

class B (object):
    def method (self):
        print "B.method"

class Mix1 (A, B):
    pass

class Mix2 (A, B):
    def method (self):
        print "Mix.method"

Mix1 ().method ()
Mix2 ().method ()

""" """

class Base (object):
    def method (self):
        print "Base.method"

class A (Base):
    def method (self):
        print "A.method"
        super (A, self).method ()

A ().method ()

class B (Base):
    def method (self):
        print "B.method"
        super (B, self).method ()

B ().method ()

class Deriv (A, B):
    def method (self):
        print "Deriv.method"
        super (Deriv, self).method ()

Deriv ().method ()

"""

"""

class Base (object):
    def __init__ (self):
        self.x = 0
class A (Base):
    def __init__ (self):
        Base.__init__ (self)
        self.x = 7
class B (Base): pass
class Deriv (A, B):
    def __init__ (self):
        A.__init__ (self)
        B.__init__ (self)
print Deriv ().x
print Deriv.__mro__

"""
"""

class Base (object):
  def __init__ (self):
    self.x = 0
class A (Base):
  def __init__ (self):
    super (A, self).__init__ ()
    self.x = 7
class B (Base): pass
class Deriv (A, B):
  def __init__ (self):
    super(Deriv,self).__init__()
print Deriv ().x

"""
"""

class Base (object):
    def __init__ (self):
        print "Base.__init__"
class OtraBase (object):
    def __init__ (self):
        print "OtraBase.__init__"
class Deriv (Base, OtraBase):
    def __init__ (self):
        print "Deriv.__init__"
        super (Deriv, self).__init__ ()
Deriv ()

"""

IMPORTANTE: El tipo del la clase superior ha
cambiado al heredar de la clase!

CONSECUENCIA:
  - Siempre hay que llamar 'super' en el
  construnctor. AUNQUE solo heredemos de 'object'!
  
  - __init__ no sabe que parametros pasar a
    'super'. Solucion, usar 'keywords' variables.
    
"""

class GoodInit (object):
    def __init__ (self, param = None, *a, **k):
        self.param = param
        super (GoodInit, self).__init__ (*a, **k)

obj = GoodInit (param = 1)
print obj.param

"""

Slots
-----

Acceder a atributos es INEFICIENTE - i.e. requiere
buscar en un diccionario.

  - __slots__ lista de atributos.

  - Un objeto con __slots__ no puede tener otros
    atributos que no esten en esa lista (salvo con
    trucos).

  - Requiere new-style class.

"""

import sizeof
import sys

class Point (object):
    def __init__ (self, x=0, y=0, *a,**k):
        super (Point, self).__init__ (*a,**k)
        self.x = x
        self.y = y

obj = Point (1, 2)
print "Non-slot: ", sizeof.asizeof (obj), sys.getsizeof (obj)

class Point (object):
    __slots__ = 'x', 'y'
    def __init__ (self, x=0, y=0, *a,**k):
        super (Point, self).__init__ (*a,**k)
        self.x = x
        self.y = y

obj = Point (1, 2)
print obj.x, obj.y
print "Slot: ", sizeof.asizeof (obj), sys.getsizeof (obj)

try:
    obj.z = 3
except AttributeError, e:
    print repr (e)

"""

Funciones especiales
--------------------

  - Son funciones que nos permiten, en general,
    sobrecargar operadores y funciones especiales.

  - Tienen la forma: __funcion__

  - Ejemplo: __init__

Operaciones de representación:

  - __str__
  - __repr__

Operaciones aritmeticas:

  - __add__, __iadd__
  - __mul__, __imul__
  - ...
  
Comparadores:

  - __gt__, __lt__,
  - __eq__, __not__,
  - ...

  - Ejemplo: clase Polinomio

Acceso atributos:

  - __getattribute__, __getattr__
  - __setattr__ 

  - Ejemplo: Proxy

Otros...

"""

import os

class MyPath (object):
    
    def __init__ (self, sep=os.sep, *a, **k):
        super (MyPath, self).__init__ (**k)
        self.sep = sep
        self._str = self.sep.join (a)
    
    def __rdiv__ (self, other):
        return MyPath (other, self._str)

    def __div__ (self, other):
        return MyPath (self._str, other)

    def __idiv__ (self, other):
        self._str = self.sep.join (
            (self._str, str (other)))
        return self
    
    def __str__ (self):
        return self._str

p = MyPath ('raskolnikov')
print p

p = '' / 'home' / p
print p

p /= 'dev'
print p

p = p / 'curso' / 'dia1' / 't03_oo.py'
print p

class Proxy (object):
    def __init__ (self, proxied=None, *a,**k):
        super (Proxy, self).__init__ (*a, **k)
        self.proxied = proxied
    def __getattr__ (self, key):
        return getattr (self.proxied, key)

a = Proxy (list ())
a.append (1)
print a
print a.proxied

class Contador (object):
    def __init__(self, inic=0, *a,**k):
        super(Contador, self).__init__(*a,**k)
        self.cuenta = inic
    def __call__ (self):
        actual = self.cuenta
        self.cuenta += 1
        return actual

cnt = Contador ()
print cnt ()
print cnt ()
print callable (cnt)

"""

Para avanzar mas aun ...
------------------------

- Mas reflectividad.
- Descriptores.
- Metaclases.

"""
