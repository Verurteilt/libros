# -*- coding: utf-8 -*-

"""

4. INTERFACES GRAFICAS
======================

  - Permiten al usuario interactuar con metaforas
    de su entorno cotidiano.

  - Permiten visualizar directamente los
    resultados y manipularlos naturalmente.

  - Evitan tener que memorizar los comandos de
    interaccion.

  - Facilitan realizar varias cosas a la vez.
  
"""

"""

GTK+
----

  - Toolkit oficial de GNOME.

  - Escrito en C.

  - Soporta muchisimos lenguajes (podemos
    reutilizar codigo y herramientas).

  - Maduro, muy usado y bonito.

  - Gtk+ es un FRAMEWORK.

Framework vs Biblioteca
-----------------------

  - BIBLIOTECA: Conjunto de funciones y clases que
    un programador puede usar.

  - FRAMEWORK: Conjunto de funciones y clases que
    definen la estructura del programa. El 'main'
    es parte del framework y el cliente instala su
    codigo mediante enganches (hooks).

    (Design Patterns, Gamma et. Al.)

'Signals' y el patron observer
------------------------------

  - Todas las clases de GTK+ heredan de
    gobject.GObject, que provee funcionalidad
    especial.
  
  - Una segnal esta idenficada por una cadena,
    para conectarnos a una segnal:

    * connect (signal, handler, ...)

    * connect_after (signal, handler, ...)

    * connect_object (signal, handler, gobject)

    * connect_object_after (signal, handler,
      gobject)

  - Creando segnales:

    * Se crean con la funcion:
      > signal_new (name, gobject, flags, return_type, param_types)
      > Esto causa problemas, es mejor usar __gsignals__
    
    * Se emiten con:
        emit (name, params...)
"""

import pygtk
pygtk.require('2.0')

import gobject

def my_handler (obj, param, *fixed):
    print " -- Handling signal -- "
    print "Obj:   ", obj
    print "Param: ", param
    print "Fixe:  ", fixed

class MyClass (gobject.GObject):
    __gsignals__ = {
        'mysig' : (gobject.SIGNAL_RUN_FIRST,
                   None,
                   (object,))
        }
    
obj = MyClass ()
obj.connect ('mysig', my_handler, 'Hola mundo!')

obj.emit ('mysig', None)
obj.emit ('mysig', 'param')

"""

Propiedades
-----------

"""
import gobject

class MyClass (gobject.GObject):
    __gproperties__ = { 
        'width' : (object,
                   'Ancho',
                   'El ancho del objeto',
                   gobject.PARAM_READWRITE)
        }
    def do_get_property (self, prop):
        return getattr (self, '_' + prop.name)
    def do_set_property (self, prop, val):
        setattr (self, '_' + prop.name, val)

#gobject.type_register ()

a = MyClass ()
a.connect ('notify::width', my_handler)
a.props.width = 10
print a.props.width


"""

Hola mundo en GTK+
------------------

  - Primero construimos los elementos iniciales
    basicos de la aplicacion.

  - Luego ejecutamos gtk.main ():

      while no_hemos_terminado:
          capturar_eventos_interfaz ()
          disparar_eventos ()

  - Para terminar ejecutamos:

      gtk.main_quit ()

"""

import gtk

win = gtk.Window ()
win.connect ('destroy', gtk.main_quit)
win.show ()

gtk.main ()

"""

Widgets / Controls
==================

  - Los diferentes elementos graficos de una
    aplicacion se llama 'widgets'.

Ventanas
--------

  - gtk.Window (wtype = gtk.WINDOW_TOPLEVEL)

    * gtk.WINDOW_POPUP se comporta comoun menu.

Boxes
-----

  - Las interfaces modernas pueden
    redimensionarse, etc. Por tanto no podemos
    poner las posiciones de los elementos
    directamente, usamos 'layouts' que
    proporcionan huecos para situar los elementos
    y que se redimensionan con diferentes 

      * gtk.Table (rows=1, columns=1, homogeneous=False)

      table.attach (child, left_attach, right_attach, top_attach, bottom_attach,
                   xoptions=EXPAND|FILL, yoptions=EXPAND|FILL, xpadding=0, ypadding=0)

      * gtk.VBox (homogeneous=False, spacing=0)

      * gtk.HBox (homogeneous=False, spacing=0)

      box.pack_start (child, expand=True, fill=True, padding=0)

      box.pack_end (child, expand=True, fill=True, padding=0)

Botones
-------

      gtk.Button (label=None, stock=None, use_underline=True)

  - 'clicked'
  - 'pressed'
  - 'released'
  - 'enter'
  - 'leave'


  Otros tipos:

     gtk.ToggleButton
     gtk.RadioButton
     gtk.CheckButton
     
Etiquetas
---------

      gtk.Label (text='')
      
"""

import gtk

win = gtk.Window ()
win.connect ('destroy', gtk.main_quit)

lab = gtk.Label ('Hola...')
btn = gtk.Button ('Pinchame')
btn.connect ('clicked', lambda *a: lab.set_text ('...mundo!'))

box = gtk.HBox ()
win.add (box)
box.pack_start (btn)
box.pack_start (lab)

win.show_all ()
gtk.main ()

"""

Menus
-----

En la creacion de menus intervienen tres tipos de
elementos fundamentales, que se relacionan
jerarquicamente:

  - MenuBar: Contiene las raices de los menus.
  - Menu: Es un menu, un contendor de opciones.

      * En estos dos agnadimos los elementos con:

           menu.append (item)
  
  - MenuItem: Es un elemento del menu.

      * Podemos establecer que un menu es un
        sub-menu de este con:

           item.set_submenu (menu)

  - Hay otra forma mas facil -- ItemFactory --
    pero nos lo vamos a saltar, ya que en verdad
    luego haremos todo esto con Glade.
  
"""

import gtk

win = gtk.Window ()
win.connect ('destroy', gtk.main_quit)

box = gtk.VBox (False, 0)
win.add (box)

menu_bar = gtk.MenuBar ()
box.pack_start (menu_bar, False)

file_menu = gtk.Menu ()
quit_item = gtk.MenuItem ('Quit')
file_menu.append (gtk.MenuItem ('Open'))
file_menu.append (gtk.MenuItem ('Save'))
quit_item = gtk.MenuItem ('Quit')
file_menu.append (quit_item)
quit_item.connect_object ('activate', gtk.Window.destroy, win)

file_item = gtk.MenuItem ('File')
file_item.set_submenu (file_menu)
menu_bar.append (file_item)

win.show_all ()
gtk.main ()

"""

Contenedores
------------

Las ventanas entre otros son 'contenedores' --
i.e. tienen un metodo add ().

Algunos de los mas utiles:

  * gtk.Notebook ()

     notebook.append_page (child, tab_label)
     notebook.prepend_page (child, tab_label)
     notebook.insert_page (child, tab_label, position)
     notebook.remove_page (page_num)
     notebook.get_current_page ()
     ...

  * gtk.Frame (label = None)

  * gtk.Fixed, gtk.Layout:

     Para poner objetos en posiciones X, Y ... no
     usar, que os veo las ganas!

  * gtk.HPaned (), gtk.VPaned ()

     paned.add1 (element)
     paned.add2 (element)

  * gtk.HButtonBox (), gtk.VButtonBox ()

  * gtk.Toolbar ()

     toolbar.append_item (text, tooltip_text, tooltip_private_text, icon, callback, user_data=None)
     toolbar.prepend_item (text, tooltip_text, tooltip_private_text, icon, callback, user_data)

"""

win = gtk.Window ()
win.connect ('destroy', gtk.main_quit)

toolbar = gtk.Toolbar ()

close_button = toolbar.append_item (
    "Open", "Open a file", "Private",        
    gtk.image_new_from_stock (gtk.STOCK_OPEN, 32),
    lambda *a: None)

close_button = toolbar.append_item (
    "Close", "Closes this app", "Private",        
    gtk.image_new_from_stock (gtk.STOCK_CLOSE, 32),            
    lambda *a: win.destroy ())

notebook = gtk.Notebook ()
notebook.append_page (gtk.Frame('Uno'), gtk.Label('Uno'))
notebook.append_page (gtk.Frame('Dos'), gtk.Label('Dos'))

box = gtk.VBox (False, 0)
box.pack_start (toolbar, False)
box.pack_start (notebook)

win.add (box)
win.show_all ()
gtk.main ()

"""

Listas
------

Las listas hace unas cuantas versiones se
volvieron un poco mas complicadas porque tienen un
disegno Modelo-Vista-Controlador.

Modelo-Vista-Controlador:

  - El 'modelo' contiene los datos (estatico).

  - La 'vista' representa lo que hay en el
    modelo. Se entera de lo que pasa por eventos
    (signals) que le envia el modelo.

  - El 'controlador' es activo, manipula el modelo.

En las listas de GTK:

  - Modelo:
      
      Herdedan de TreeModel: TreeStore, ListStore,
      TreeModelSort, TreeModelFilter ...

  - Vista:

      TreeView

        * Se organiza por TreeViewColumn
        * Cada columna tiene asociado un
          CellRenderer(Pixbuf|Text|Toggle) para
          representar los datos
        
  - Controlador:

      El codigo del usuario que ejecuta funcuiones
      sobre el 'store'.

"""

import pygtk
pygtk.require ('2.0')
import gtk
import gobject

win = gtk.Window ()
win.connect ('destroy', gtk.main_quit)

model = gtk.ListStore (gobject.TYPE_BOOLEAN,
                       gobject.TYPE_STRING)

view = gtk.TreeView (model)
view.append_column (gtk.TreeViewColumn (
    'Done', gtk.CellRendererToggle (), active = 0))
view.append_column (gtk.TreeViewColumn (
    'Task', gtk.CellRendererText (), text = 1))

model.append ((True,  'Python avanzado.'))
model.append ((False, 'Interfaces graficas.'))
model.append ((False, 'Django.'))

win.add (view)
win.show_all ()
gtk.main ()

"""

Otros widgets:

  - TreeView <-> TextBuffer: Editor de texto MVC.

  - Calendarios.

  - Muchisimos mas!

"""

"""
show how to add a matplotlib FigureCanvasGTK or FigureCanvasGTKAgg widget and
a toolbar to a gtk.Window
"""
import gtk

from matplotlib.figure import Figure
from numpy import arange, sin, pi

# uncomment to select /GTK/GTKAgg/GTKCairo

# from matplotlib.backends.backend_gtk \
#      import FigureCanvasGTK as FigureCanvas
# from matplotlib.backends.backend_gtkagg \
#      import FigureCanvasGTKAgg as FigureCanvas

from matplotlib.backends.backend_gtkcairo \
     import FigureCanvasGTKCairo as FigureCanvas

# or NavigationToolbar for classic

# from matplotlib.backends.backend_gtk \
#      import NavigationToolbar2GTK as NavigationToolbar

from matplotlib.backends.backend_gtkagg \
     import NavigationToolbar2GTKAgg as NavigationToolbar

win = gtk.Window ()
win.connect ("destroy", gtk.main_quit)
win.set_default_size (400, 300)
win.set_title ("Embedding in GTK")

vbox = gtk.VBox ()
win.add (vbox)

fig = Figure (figsize=(5, 4), dpi=100)
ax = fig.add_subplot (111)
t = arange (0.0, 3.0, 0.01)
s = sin (2 * pi * t)
ax.plot (t, s)

canvas = FigureCanvas (fig)  # a gtk.DrawingArea
vbox.pack_start (canvas)
toolbar = NavigationToolbar(canvas, win)
vbox.pack_start(toolbar, False, False)

win.show_all ()
gtk.main ()

"""

Glade
-----

Editar interfaces graficas por codigo tiene varios
PROBLEMAS:

  - Separa la edicion y ver el resultado, puede
    resultar en interfaces feas y poco usables.

  - Es dificil memorizar todos los widgets que
    tenemos a mano.

  - Fomenta acoplar codigo y visualizacion.
    Idealmente, el disegnador trabaja en la
    interfaz y el programador en como reacciona el
    codigo.
    
SOLUCION:

  - Usar un editor de interfaces graficas.

  - La interfaz se guarda en un fichero XML
    (ejemplo).
    
  - Antes habia que depender de libglade, ahora
    GTK incluye la clase gtk.Builder.
    
"""

from matplotlib.figure import Figure
import numpy
import pyfits as fits
import gtk
import img_scale

# Descomentar para elegir GTK, GTKAgg o GTKCairo
#
# from matplotlib.backends.backend_gtk import FigureCanvasGTK as FigureCanvas
# from matplotlib.backends.backend_gtkagg import FigureCanvasGTKAgg as FigureCanvas
#

from matplotlib.backends.backend_gtkcairo import FigureCanvasGTKCairo as FigureCanvas


win = gtk.Window(gtk.WINDOW_TOPLEVEL)
win.connect ('destroy', gtk.main_quit)

f = fits.open ('pic/WFPC2u5780205r_c0fx.fits')
data = f[0].data
w, h = data[0].shape
img = numpy.zeros ((w, h, 3), dtype = float)
img[:,:,0] = img_scale.sqrt (data[0], scale_min=0, scale_max=255)
#img[:,:,1] = img_scale.sqrt (data[1], scale_min=0, scale_max=255)
#img[:,:,2] = img_scale.sqrt (data[2], scale_min=0, scale_max=255)

f = Figure(figsize=(5,4),
           dpi=100)
a = f.add_subplot(111)
a.imshow (img)

canvas = FigureCanvas (f)  # a gtk.DrawingArea
win.add (canvas)

win.show_all ()
gtk.main ()

