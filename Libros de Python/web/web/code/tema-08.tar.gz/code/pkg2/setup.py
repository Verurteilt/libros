#!/usr/bin/env python

from distutils.core import setup, Extension

setup (
    name         = 'CrazySoft',
    version      = '1.3',
    description  = 'Crazy package that is cool',
    author       = 'Crazy Author',
    author_email = 'raskolnikov@gnu.org',
    url          = 'http://www.iaa.es',
    packages     = ['crazymod'],
    ext_modules  = [Extension('crazymod.mymod', ['crazymod/mymod.c']),
                    Extension('_crazyfuncs', ['crazymod/funcs.c'])],
    )
