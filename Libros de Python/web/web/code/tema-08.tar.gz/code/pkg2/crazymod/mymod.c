#include <Python.h>

static char mymod_doc[] = 
  "This module is just a simple example.  It provides one function: func().";

static PyObject*
mymod_func(PyObject *self, PyObject *args)
{
  PyObject *a, *b;
	
  if (!PyArg_UnpackTuple(args, "func", 2, 2, &a, &b)) {
    return NULL;
  }

  return PyNumber_Add(a, b);
}

static char mymod_func_doc[] = 
  "func(a, b)\n\
\n\
Return the sum of a and b.";

static PyMethodDef mymod_methods[] = {
  {"func", mymod_func, METH_VARARGS, mymod_func_doc},
  {NULL, NULL}
};

PyMODINIT_FUNC
initmymod(void)
{
  Py_InitModule3("mymod", mymod_methods, mymod_doc);
}
