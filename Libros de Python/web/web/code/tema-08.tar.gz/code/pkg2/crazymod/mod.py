
def crazyfunc ():
    print "Yabadabadooh!"


from ctypes import *
from numpy.ctypeslib import ndpointer
import sys
from os import path

def load_ctypes_extension (name):
    lib = None
    for x in sys.path:
        try:
            lib = cdll.LoadLibrary (path.join (x, name))
            break
        except OSError:
            pass
    if not lib:
        raise ImportError, "Could not find C library: " + name
    return lib

_funcs = load_ctypes_extension ('_crazyfuncs.so')

vec3 = ndpointer (dtype = 'float32',
                  ndim  = 1,
                  shape = (3,),
                  flags = 'C_CONTIGUOUS')
_funcs.dotprod3.argtypes = vec3, vec3
_funcs.dotprod3.restype  = c_float


