"""

DISTRIBUYENDO EL SOFTWARE
=========================

  - Tenemos que buscar herramientas para facilitar
    la distribucion del software -- i.e. crear
    instaladores, etc.

  - Python, por ser un lenguaje interpretado,
    tiene su propia idiosincracia.

  - Afortunadamente, la biblioteca estandar nos lo
    pone muy facil.

"""

"""

Pasos:

  - Escribir un script de instalacion (setup.py por convencion).

  - Opcional: Escribir un fichero de configuracion de la instalacion.

  - Crear una distribucion del codigo fuente.

  - Opcional: Crear un o varias distribuciones binarias.

"""

"""

Modulos
-------

"""

from distutils.core import setup

setup (
    name         = 'Distutils',
    version      = '1.0',
    description  = 'Python Distribution Utilities',
    author       = 'Greg Ward',
    author_email = 'gward@python.net',
    url          = 'http://www.python.org/sigs/distutils-sig/',
    packages     = ['distutils', 'distutils.command'],
    )

"""

  - 'packages' no busca recursivamente.
  
  - Si no existe correspondencia entre los
    paquetes y donte estan instalados se puede
    usar:

      package_dir = {'':     'lib'}
      package_dir = {'foo' : 'lib'}

  - Si solo queremos distribuir modulos sueltos
    --i.e. no hay paquete-- usamos:

      py_modules = ['mod1', 'pkg.mod2']

"""


"""

Extensiones
-----------

  - Tenemos que decirle los ficheros C y como
    compilarlos:

    ext_modules = [Extension('foo', ['foo.c'])],

  - Tiene soporte para SWIG:

     setup(...,
     ext_modules=[Extension('_foo', ['foo.i'],
     swig_opts=['-modern', '-I../include'])],
     py_modules=['foo'],
     )

  - La clase Extension soporta tambien:

      include_dirs=['/usr/include/X11']
  
      define_macros = [('NDEBUG', '1'),
                       ('HAVE_STRFTIME', None)],

      undef_macros = ['HAVE_FOO', 'HAVE_BAR']

  - NOTA: Las bibliotecas encapsuladas con CTypes
    son di.
    
"""

"""

Scripts
-------

"""

"""

Configuracion
-------------

"""

"""

Ficheros extra
--------------

"""

"""

Paquetes
--------

"""
