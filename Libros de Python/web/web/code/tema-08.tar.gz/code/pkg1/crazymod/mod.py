
def crazyfunc ():
    print "Yabadabadooh!"

